// Script para diagnosticar y solucionar problemas de autenticación
const mysql = require("mysql2/promise")
const bcrypt = require("bcryptjs")
require("dotenv").config()

// Configuración de la base de datos
const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "casa_muebla_carpinteria",
  port: process.env.DB_PORT || 3306,
}

// Usuarios predeterminados
const defaultUsers = [
  {
    nombre_usuario: "Administrador",
    email_usuario: "admin@casamuebla.com",
    password: "Admin123",
    rol: "admin",
  },
  {
    nombre_usuario: "Empleado",
    email_usuario: "empleado@casamuebla.com",
    password: "Empleado123",
    rol: "empleado",
  },
  {
    nombre_usuario: "Cliente",
    email_usuario: "cliente@casamuebla.com",
    password: "Cliente123",
    rol: "cliente",
  },
]

async function main() {
  let connection

  try {
    console.log("Conectando a la base de datos...")
    connection = await mysql.createConnection(dbConfig)
    console.log("Conexión exitosa a la base de datos.")

    // Verificar si la tabla usuarios existe
    console.log("Verificando si la tabla usuarios existe...")
    const [tables] = await connection.query(
      `
      SELECT TABLE_NAME 
      FROM information_schema.TABLES 
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'usuarios'
    `,
      [dbConfig.database],
    )

    if (tables.length === 0) {
      console.error('Error: La tabla "usuarios" no existe en la base de datos.')
      return
    }

    // Verificar si los usuarios existen
    console.log("Verificando si los usuarios existen...")
    const emails = defaultUsers.map((user) => user.email_usuario)
    const [existingUsers] = await connection.query(
      "SELECT id_usuario, email_usuario, password, rol FROM usuarios WHERE email_usuario IN (?)",
      [emails],
    )

    console.log(`Se encontraron ${existingUsers.length} de ${defaultUsers.length} usuarios.`)

    // Verificar contraseñas de usuarios existentes
    for (const user of existingUsers) {
      const defaultUser = defaultUsers.find((u) => u.email_usuario === user.email_usuario)
      if (defaultUser) {
        console.log(`\nVerificando usuario: ${user.email_usuario} (${user.rol})`)

        try {
          // Verificar si la contraseña coincide
          const passwordIsValid = await bcrypt.compare(defaultUser.password, user.password)

          if (passwordIsValid) {
            console.log(`✅ La contraseña para ${user.email_usuario} es correcta.`)
          } else {
            console.log(`❌ La contraseña para ${user.email_usuario} es incorrecta.`)

            // Actualizar la contraseña
            console.log(`Actualizando la contraseña para ${user.email_usuario}...`)
            const hashedPassword = await bcrypt.hash(defaultUser.password, 10)
            await connection.query("UPDATE usuarios SET password = ? WHERE id_usuario = ?", [
              hashedPassword,
              user.id_usuario,
            ])
            console.log(`✅ Contraseña actualizada para ${user.email_usuario}.`)
          }
        } catch (error) {
          console.error(`Error al verificar la contraseña para ${user.email_usuario}:`, error.message)

          // Si hay un error al comparar (posiblemente formato incorrecto), actualizar la contraseña
          console.log(`Actualizando la contraseña para ${user.email_usuario} debido a error...`)
          const hashedPassword = await bcrypt.hash(defaultUser.password, 10)
          await connection.query("UPDATE usuarios SET password = ? WHERE id_usuario = ?", [
            hashedPassword,
            user.id_usuario,
          ])
          console.log(`✅ Contraseña actualizada para ${user.email_usuario}.`)
        }
      }
    }

    // Crear usuarios que no existen
    const existingEmails = existingUsers.map((user) => user.email_usuario)
    const usersToCreate = defaultUsers.filter((user) => !existingEmails.includes(user.email_usuario))

    if (usersToCreate.length > 0) {
      console.log(`\nCreando ${usersToCreate.length} usuarios nuevos...`)

      for (const user of usersToCreate) {
        const hashedPassword = await bcrypt.hash(user.password, 10)
        await connection.query(
          "INSERT INTO usuarios (nombre_usuario, email_usuario, password, rol) VALUES (?, ?, ?, ?)",
          [user.nombre_usuario, user.email_usuario, hashedPassword, user.rol],
        )
        console.log(`✅ Usuario creado: ${user.email_usuario} (${user.rol})`)
      }
    }

    console.log("\n✅ Proceso completado. Ahora deberías poder iniciar sesión con las credenciales predeterminadas.")
  } catch (error) {
    console.error("Error:", error.message)
    if (error.code === "ECONNREFUSED") {
      console.error(
        "No se pudo conectar a la base de datos. Verifica que el servidor MySQL esté en ejecución y que las credenciales sean correctas.",
      )
    }
  } finally {
    if (connection) {
      await connection.end()
      console.log("Conexión a la base de datos cerrada.")
    }
  }
}

main()
