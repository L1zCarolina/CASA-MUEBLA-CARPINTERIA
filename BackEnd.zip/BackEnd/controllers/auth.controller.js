/// CONTROLADORES DEL MODULO ///

const db = require("../db/db")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")

//---------------- METODOS HTTP ---------------------///

/// METODO POST - REGISTRO ///
const register = (req, res) => {
  console.log("=== REGISTRO DE USUARIO ===")
  console.log("Archivo recibido:", req.file)
  console.log("Datos del formulario:", req.body)

  const { nombre_usuario, email_usuario, password, rol } = req.body
  const foto_perfil = req.file ? req.file.filename : null

  // Validaciones básicas
  if (!nombre_usuario || !email_usuario || !password) {
    return res.status(400).json({
      error: "Campos obligatorios: nombre_usuario, email_usuario, password",
    })
  }

  if (password.length < 6) {
    return res.status(400).json({
      error: "La contraseña debe tener al menos 6 caracteres",
    })
  }

  // Verificar si el email ya existe
  const checkSql = "SELECT id_usuario FROM usuarios WHERE email_usuario = ?"
  db.query(checkSql, [email_usuario], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar email:", checkError)
      return res.status(500).json({ error: "Error al verificar email" })
    }

    if (checkResults.length > 0) {
      return res.status(409).json({ error: "El email ya está registrado" })
    }

    // Encriptar contraseña
    const hashedPassword = bcrypt.hashSync(password, 8)
    const rolFinal = rol || "cliente"

    const sql = "INSERT INTO usuarios (nombre_usuario, email_usuario, password, rol, foto_perfil) VALUES (?,?,?,?,?)"
    db.query(sql, [nombre_usuario, email_usuario, hashedPassword, rolFinal, foto_perfil], (error, result) => {
      if (error) {
        console.error("Error al registrar usuario:", error)
        return res.status(500).json({ error: "ERROR: No se pudo registrar el usuario" })
      }

      // Crear token JWT
      const token = jwt.sign(
        {
          id_usuario: result.insertId,
          nombre_usuario,
          email_usuario,
          rol: rolFinal,
        },
        process.env.SECRET_KEY || "tu_clave_secreta",
        { expiresIn: "24h" },
      )

      const usuario = {
        id_usuario: result.insertId,
        nombre_usuario,
        email_usuario,
        rol: rolFinal,
        foto_perfil,
        fecha_registro: new Date(),
      }

      console.log("Usuario registrado exitosamente:", usuario)
      res.status(201).json({
        mensaje: "✅ Usuario registrado exitosamente",
        usuario: usuario,
        token: token,
      })
    })
  })
}

/// METODO POST - LOGIN ///
const login = (req, res) => {
  console.log("=== LOGIN DE USUARIO ===")
  console.log("Datos recibidos:", req.body)

  const { email_usuario, password } = req.body

  // Validaciones básicas
  if (!email_usuario || !password) {
    return res.status(400).json({
      error: "Email y contraseña son obligatorios",
    })
  }

  // Buscar usuario por email
  const sql = "SELECT * FROM usuarios WHERE email_usuario = ?"
  db.query(sql, [email_usuario], (error, results) => {
    if (error) {
      console.error("Error al buscar usuario:", error)
      return res.status(500).json({ error: "Error en el servidor" })
    }

    if (results.length === 0) {
      return res.status(401).json({ error: "Email o contraseña incorrectos" })
    }

    const usuario = results[0]

    // Verificar contraseña
    const passwordIsValid = bcrypt.compareSync(password, usuario.password)
    if (!passwordIsValid) {
      return res.status(401).json({ error: "Email o contraseña incorrectos" })
    }

    // Crear token JWT
    const token = jwt.sign(
      {
        id_usuario: usuario.id_usuario,
        nombre_usuario: usuario.nombre_usuario,
        email_usuario: usuario.email_usuario,
        rol: usuario.rol,
      },
      process.env.SECRET_KEY || "tu_clave_secreta",
      { expiresIn: "24h" },
    )

    const usuarioResponse = {
      id_usuario: usuario.id_usuario,
      nombre_usuario: usuario.nombre_usuario,
      email_usuario: usuario.email_usuario,
      rol: usuario.rol,
      foto_perfil: usuario.foto_perfil,
    }

    console.log("Login exitoso para:", usuarioResponse)
    res.json({
      mensaje: "✅ Login exitoso",
      usuario: usuarioResponse,
      token: token,
    })
  })
}

/// METODO GET - OBTENER PERFIL ///
const getMe = (req, res) => {
  const userId = req.userId

  const sql =
    "SELECT id_usuario, nombre_usuario, email_usuario, rol, foto_perfil, fecha_registro FROM usuarios WHERE id_usuario = ?"
  db.query(sql, [userId], (error, results) => {
    if (error) {
      console.error("Error al obtener perfil:", error)
      return res.status(500).json({ error: "Error al obtener perfil" })
    }

    if (results.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" })
    }

    res.json(results[0])
  })
}

/// METODO POST - VERIFICAR TOKEN ///
const verifyToken = (req, res) => {
  res.json({
    mensaje: "Token válido",
    usuario: req.user,
  })
}

/// METODO POST - CAMBIAR CONTRASEÑA ///
const changePassword = (req, res) => {
  const userId = req.userId
  const { password_actual, password_nueva } = req.body

  // Validaciones
  if (!password_actual || !password_nueva) {
    return res.status(400).json({
      error: "Se requiere contraseña actual y nueva contraseña",
    })
  }

  if (password_nueva.length < 6) {
    return res.status(400).json({
      error: "La nueva contraseña debe tener al menos 6 caracteres",
    })
  }

  // Obtener usuario actual
  const sql = "SELECT * FROM usuarios WHERE id_usuario = ?"
  db.query(sql, [userId], (error, results) => {
    if (error) {
      console.error("Error al obtener usuario:", error)
      return res.status(500).json({ error: "Error al cambiar contraseña" })
    }

    if (results.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" })
    }

    const usuario = results[0]

    // Verificar contraseña actual
    const passwordIsValid = bcrypt.compareSync(password_actual, usuario.password)
    if (!passwordIsValid) {
      return res.status(401).json({ error: "Contraseña actual incorrecta" })
    }

    // Encriptar nueva contraseña
    const hashedPassword = bcrypt.hashSync(password_nueva, 8)

    // Actualizar contraseña
    const updateSql = "UPDATE usuarios SET password = ? WHERE id_usuario = ?"
    db.query(updateSql, [hashedPassword, userId], (updateError, updateResult) => {
      if (updateError) {
        console.error("Error al actualizar contraseña:", updateError)
        return res.status(500).json({ error: "Error al actualizar contraseña" })
      }

      res.json({ mensaje: "✅ Contraseña actualizada exitosamente" })
    })
  })
}

/// METODO POST - VERIFICAR CÓDIGO DE AUTORIZACIÓN ///
const verifyAuthorizationCode = (req, res) => {
  // Esta función puede ser para verificación de email o 2FA
  // Por ahora retornamos éxito
  res.json({ mensaje: "Código verificado exitosamente" })
}

// EXPORTAR FUNCIONES
module.exports = {
  register,
  login,
  getMe,
  verifyToken,
  changePassword,
  verifyAuthorizationCode,
}
