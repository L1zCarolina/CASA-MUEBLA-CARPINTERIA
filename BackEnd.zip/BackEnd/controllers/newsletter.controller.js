/// CONTROLADORES DEL MODULO ///

const db = require("../db/db")

//---------------- METODOS HTTP ---------------------///

/// METODO GET  ///

// Para todas las suscripciones
const allSubscriptions = (req, res) => {
  const sql = "SELECT * FROM newsletter ORDER BY fecha_suscripcion DESC"
  db.query(sql, (error, rows) => {
    if (error) {
      console.error("Error en allSubscriptions:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }

    // ← ASEGURAR QUE SIEMPRE SE ENVÍE ARRAY
    const suscripciones = Array.isArray(rows) ? rows : []
    console.log(`Enviando ${suscripciones.length} suscripciones`)
    res.json(suscripciones)
  })
}

// Para una suscripción específica
const showSubscription = (req, res) => {
  const { id } = req.params
  const sql = "SELECT * FROM newsletter WHERE id_newsletter = ?"
  db.query(sql, [id], (error, rows) => {
    if (error) {
      console.error("Error en showSubscription:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    if (rows.length === 0) {
      return res.status(404).json({ error: "ERROR: No existe la suscripción buscada" })
    }
    res.json(rows[0])
  })
}

/// METODO POST  ///

// Crear nueva suscripción
const storeSubscription = (req, res) => {
  console.log("=== NUEVA SUSCRIPCIÓN ===")
  console.log("Datos del formulario:", req.body)

  const { email_suscriptor, nombre_suscriptor } = req.body

  // Validación básica
  if (!email_suscriptor) {
    return res.status(400).json({
      error: "El email es obligatorio para suscribirse",
    })
  }

  // Validar formato de email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email_suscriptor)) {
    return res.status(400).json({
      error: "El formato del email no es válido",
    })
  }

  // Verificar si el email ya está suscrito
  const checkSql = "SELECT id_newsletter FROM newsletter WHERE email_suscriptor = ?"
  db.query(checkSql, [email_suscriptor], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar suscripción:", checkError)
      return res.status(500).json({ error: "Error al verificar suscripción" })
    }

    if (checkResults.length > 0) {
      return res.status(409).json({ error: "Este email ya está suscrito al newsletter" })
    }

    const sql = "INSERT INTO newsletter (email_suscriptor, nombre_suscriptor, activo) VALUES (?,?,?)"
    db.query(sql, [email_suscriptor, nombre_suscriptor || null, true], (error, result) => {
      if (error) {
        console.error("Error al crear suscripción:", error)
        return res.status(500).json({
          error: "ERROR: No se pudo procesar la suscripción",
        })
      }

      // ← RESPUESTA CONSISTENTE
      const suscripcion = {
        id_newsletter: result.insertId,
        email_suscriptor,
        nombre_suscriptor: nombre_suscriptor || null,
        fecha_suscripcion: new Date(),
        activo: true,
      }

      console.log("Suscripción creada exitosamente:", suscripcion)
      res.status(201).json({
        mensaje: "✅ ¡Gracias por suscribirte a nuestro newsletter!",
        suscripcion: suscripcion,
      })
    })
  })
}

/// METODO PUT  ///

// Actualizar suscripción
const updateSubscription = (req, res) => {
  console.log("=== ACTUALIZAR SUSCRIPCIÓN ===")
  const { id } = req.params
  console.log("ID a actualizar:", id)
  console.log("Datos del formulario:", req.body)

  const { email_suscriptor, nombre_suscriptor, activo } = req.body

  // Validación básica
  if (!email_suscriptor) {
    return res.status(400).json({
      error: "El email es obligatorio",
    })
  }

  // Validar formato de email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!emailRegex.test(email_suscriptor)) {
    return res.status(400).json({
      error: "El formato del email no es válido",
    })
  }

  // ← VERIFICAR QUE LA SUSCRIPCIÓN EXISTE ANTES DE ACTUALIZAR
  const checkSql = "SELECT * FROM newsletter WHERE id_newsletter = ?"
  db.query(checkSql, [id], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar suscripción:", checkError)
      return res.status(500).json({ error: "Error al verificar suscripción" })
    }

    if (checkResults.length === 0) {
      return res.status(404).json({ error: "Suscripción no encontrada" })
    }

    // Verificar si el email ya existe en otra suscripción
    const emailCheckSql = "SELECT id_newsletter FROM newsletter WHERE email_suscriptor = ? AND id_newsletter != ?"
    db.query(emailCheckSql, [email_suscriptor, id], (emailError, emailResults) => {
      if (emailError) {
        console.error("Error al verificar email:", emailError)
        return res.status(500).json({ error: "Error al verificar email" })
      }

      if (emailResults.length > 0) {
        return res.status(409).json({ error: "Ya existe una suscripción con ese email" })
      }

      const updateSql =
        "UPDATE newsletter SET email_suscriptor = ?, nombre_suscriptor = ?, activo = ? WHERE id_newsletter = ?"
      db.query(
        updateSql,
        [email_suscriptor, nombre_suscriptor || null, activo !== undefined ? activo : true, id],
        (error, result) => {
          if (error) {
            console.error("Error al actualizar suscripción:", error)
            return res.status(500).json({ error: "ERROR: No se pudo actualizar la suscripción" })
          }

          if (result.affectedRows === 0) {
            return res.status(404).json({ error: "ERROR: La suscripción a modificar no existe" })
          }

          // ← RESPUESTA CONSISTENTE
          const suscripcionActualizada = {
            id_newsletter: Number.parseInt(id),
            email_suscriptor,
            nombre_suscriptor: nombre_suscriptor || null,
            activo: activo !== undefined ? activo : true,
          }

          console.log("Suscripción actualizada exitosamente:", suscripcionActualizada)
          res.json({
            mensaje: "✅ Suscripción actualizada exitosamente",
            suscripcion: suscripcionActualizada,
          })
        },
      )
    })
  })
}

/// METODO DELETE ///

// Eliminar suscripción (desuscribir)
const destroySubscription = (req, res) => {
  const { id } = req.params

  const sql = "DELETE FROM newsletter WHERE id_newsletter = ?"
  db.query(sql, [id], (error, result) => {
    if (error) {
      console.error("Error al eliminar suscripción:", error)
      return res.status(500).json({ error: "ERROR: No se pudo procesar la desuscripción" })
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "ERROR: La suscripción no existe" })
    }
    res.json({ mensaje: "✅ Desuscripción exitosa" })
  })
}

/// METODO POST - DESUSCRIBIR POR EMAIL ///

// Desuscribir por email (para enlaces de desuscripción)
const unsubscribeByEmail = (req, res) => {
  const { email_suscriptor } = req.body

  if (!email_suscriptor) {
    return res.status(400).json({
      error: "El email es obligatorio para desuscribirse",
    })
  }

  const sql = "DELETE FROM newsletter WHERE email_suscriptor = ?"
  db.query(sql, [email_suscriptor], (error, result) => {
    if (error) {
      console.error("Error al desuscribir:", error)
      return res.status(500).json({ error: "ERROR: No se pudo procesar la desuscripción" })
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "ERROR: El email no está suscrito" })
    }
    res.json({ mensaje: "✅ Te has desuscrito exitosamente del newsletter" })
  })
}

// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
  allSubscriptions,
  showSubscription,
  storeSubscription,
  updateSubscription,
  destroySubscription,
  unsubscribeByEmail,
}
