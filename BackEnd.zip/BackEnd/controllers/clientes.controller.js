/// CONTROLADORES DEL MODULO ///

const db = require("../db/db");

//// METODO GET  /////

// Para todos los clientes
const allClients = (req, res) => {
    const sql = "SELECT * FROM clientes";
    db.query(sql, (error, rows) => {
        if(error){
            return res.status(500).json({error : "ERROR: Intente mas tarde por favor"});
        }
        res.json(rows);
    }); 
};

// Para un cliente
const showClient = (req, res) => {
    const {id} = req.params;
    const sql = "SELECT * FROM clientes WHERE id_cliente = ?";
    db.query(sql, [id], (error, rows) => {
        if (error) return res.status(500).json({ error: "ERROR: Intente más tarde por favor" });
        if (rows.length === 0) return res.status(404).json({ error: "ERROR: No existe el cliente buscado" });
        res.json(rows[0]); 
    }); 
};

//// METODO POST  ////
// Para crear clientes
const storeClient = (req, res) => {
    const {id_usuario, nombre_cliente, apellido_cliente, telefono_cliente, direccion_cliente, ciudad, estado, codigo_postal} = req.body;

    const sql = "INSERT INTO clientes ( id_usuario, nombre_cliente, apellido_cliente, telefono_cliente, direccion_cliente, ciudad, estado, codigo_postal) VALUES (?,?,?,?,?,?,?,?)";

db.query(sql,[id_usuario || null, nombre_cliente, apellido_cliente, telefono_cliente, direccion_cliente, ciudad, estado, codigo_postal], (error, result) => {
        if (error) return res.status(500).json({ error: "ERROR: Intente más tarde por favor" });
            if (result.affectedRows === 0) return res.status(404).json({ error: "ERROR: El cliente a modificar no existe" });
        res.json({ id_cliente: id, ...req.body });
    });     
};

//// METODO PUT  ////
// Para agregar
const updateClient = (req, res) => {
    const {id} = req.params;
    const { nombre_cliente, apellido_cliente, telefono_cliente, direccion_cliente, ciudad, estado, codigo_postal } = req.body;
    const sql ="UPDATE clientes SET  nombre_cliente = apellido_cliente = ?, telefono_cliente = ?, direccion_cliente = ?, ciudad = ?, estado = ?, codigo_postal = ? WHERE id_cliente = ?";
db.query(sql,[ nombre_cliente, apellido_cliente, telefono_cliente, direccion_cliente, ciudad, estado, codigo_postal, id] , (error, result) => {
        console.log(result);
        if(error){
            return res.status(500).json({error : "ERROR: Intente mas tarde por favor"});
        }
        if(result.affectedRows == 0){
            return res.status(404).send({error : "ERROR: El cliente a modificar no existe"});
        };
        
        res.json({ id_cliente: id, ...req.body });
    });     
};

//// METODO DELETE ////
// Para eliminar
const destroyClient = (req, res) => {
    const { id } = req.params;
    const sql = "DELETE FROM clientes WHERE id_cliente = ?";
    db.query(sql, [id], (error, result) => {
        if (error) return res.status(500).json({ error: "ERROR: Intente más tarde por favor" });
        if (result.affectedRows === 0) return res.status(404).json({ error: "ERROR: El cliente a borrar no existe" });
        res.json({ mensaje: "Cliente Eliminado" });
    }); 
};

// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
    allClients,
    showClient,
    storeClient,
    updateClient,
    destroyClient
};