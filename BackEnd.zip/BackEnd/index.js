// Primero, se importa todas las dependencias
require('dotenv').config(); // Carga variables de entorno desde un archivo .env
// Importar dependencias
const express = require('express');
const cors = require('cors'); //ayuda a manejar problemas de seguridad relacionados con solicitudes de diferentes dominios.
const morgan = require('morgan');//proporciona información valiosa sobre las solicitudes que llegan a tu API, lo que es crucial para el desarrollo y la depuración.
const path = require("path");
const errorMiddleware = require("./middlewares/error.middleware");// Importar middleware de error (si existe)


// Despues, Se Inicializa La Aplicación Express
const app = express()


// Ahora se Configura CORS y otros middelewares
app.use(cors({
  origin: '*', // En desarrollo, se puede permitir todas las origenes
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// Configuración de middlewares
app.use(morgan('dev')); // Registra las solicitudes HTTP para debugging
app.use(express.json()); // Parsea solicitudes con payloads JSON
app.use(express.urlencoded({extended:false})); // Parsea solicitudes con payloads codificados en URL

// Rutas estáticos
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static("uploads"));

// Importar rutas
const authRouter = require("./routers/auth.router");
const productosRouter = require("./routers/productos.router");
const categoriasRouter = require("./routers/categorias.router");
const clientesRouter = require("./routers/clientes.router");
const pedidosRouter = require("./routers/pedidos.router");
const detallesPedidosRouter = require("./routers/detalles_pedidos.router");
const proveedoresRouter = require("./routers/proveedores.router");
const materialesRouter = require("./routers/materiales.router");
const materialesProductoRouter = require("./routers/materiales_producto.router");
const usuariosRouter = require("./routers/usuarios.router");
const cotizacionesRouter = require("./routers/cotizaciones.router");
const comentariosRouter = require("./routers/comentarios_producto.router");
const comprasProveedorRouter = require("./routers/compras_proveedor.router");
const detallesCompraRouter = require("./routers/detalles_compra.router");
const configuracionRouter = require("./routers/configuracion.router");
const contactosRouter = require("./routers/contactos.router");
const imagenesProductoRouter = require("./routers/imagenes_producto.router");
const newsletterRouter = require("./routers/newsletter.router");
const pagosRouter = require("./routers/pagos.router");

// Configurar rutas API
app.use("/api/auth", authRouter);
app.use("/api/productos", productosRouter);
app.use("/api/categorias", categoriasRouter);
app.use("/api/clientes", clientesRouter);
app.use("/api/pedidos", pedidosRouter);
app.use("/api/detalles-pedidos", detallesPedidosRouter);
app.use("/api/proveedores", proveedoresRouter);
app.use("/api/materiales", materialesRouter);
app.use("/api/materiales_producto", materialesProductoRouter);
app.use("/api/usuarios", usuariosRouter);
app.use("/api/cotizaciones", cotizacionesRouter);
app.use("/api/comentarios_producto", comentariosRouter);
app.use("/api/compras_proveedor", comprasProveedorRouter);
app.use("/api/detalles_compra", detallesCompraRouter);
app.use("/api/configuracion", configuracionRouter);
app.use("/api/contactos", contactosRouter);
app.use("/api/imagenes_producto", imagenesProductoRouter);
app.use("/api/newsletter", newsletterRouter);
app.use("/api/pagos", pagosRouter);

// Ruta para servir el frontend
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"))
});

// Middleware de manejo de errores (que debe estar después de todas las rutas)
app.use(errorMiddleware)

// Iniciar servidor
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
  console.log(`Ambiente: ${process.env.NODE_ENV || "desarrollo"}`);
});

// Manejo de errores no capturados
process.on("uncaughtException", (error) => {
  console.error("Error no capturado:", error);
});