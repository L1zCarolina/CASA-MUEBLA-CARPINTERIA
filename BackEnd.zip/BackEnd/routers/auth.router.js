/// RUTAS DEL MODULO ///
const express = require("express")
const router = express.Router()
const db = require("../db/db")
const bcrypt = require("bcryptjs")

// DEBUG: Verificar import
console.log("=== IMPORTANDO UPLOAD EN AUTH ROUTER ===")
const upload = require("../middlewares/upload.middleware")
console.log("Upload en auth router:", typeof upload)
console.log("Upload.single en auth router:", typeof upload.single)

//// AUTH ////
const controller = require("../controllers/auth.controller")
const authMiddleware = require("../middlewares/auth.middleware")

//// METODO POST  ////
// Temporalmente sin upload para que funcione
router.post("/register", controller.register) // ← SIN UPLOAD TEMPORALMENTE
router.post("/login", controller.login)
router.post("/verify-code", controller.verifyAuthorizationCode)

// Se añade un endpoint para cambiar la contraseña
router.post("/change-password", authMiddleware, controller.changePassword)

//// METODO GET  ////
router.get("/protected", authMiddleware, (req, res) => {
  res.status(200).send(`Hola Usuario ${req.userId}`)
})

router.get("/me", authMiddleware, controller.getMe)

router.get("/verify", authMiddleware, controller.verifyToken)

// EXPORTAR ROUTERS
module.exports = router
