/// CONTROLADORES DEL MODULO ///

const db = require("../db/db")

//// METODO GET  /////

// Para todas las relaciones material-producto
const allProductMaterials = (req, res) => {
  const sql = "SELECT * FROM materiales_producto ORDER BY id_material_producto DESC"
  db.query(sql, (error, rows) => {
    if (error) {
      console.error("Error en allProductMaterials:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    const relaciones = Array.isArray(rows) ? rows : []
    res.json(relaciones)
  })
}

// Para una relación material-producto
const showProductMaterial = (req, res) => {
  const { id } = req.params
  const sql = "SELECT * FROM materiales_producto WHERE id_material_producto = ?"
  db.query(sql, [id], (error, rows) => {
    if (error) {
      console.error("Error en showProductMaterial:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    if (rows.length == 0) {
      return res.status(404).json({ error: "ERROR: No existe la relación buscada" })
    }
    res.json(rows[0])
  })
}

//// METODO POST  ////
const storeProductMaterial = (req, res) => {
  const { id_producto, id_material, cantidad } = req.body

  // Validaciones básicas
  if (!id_producto || !id_material || !cantidad) {
    return res.status(400).json({
      error: "Campos obligatorios: id_producto, id_material, cantidad",
    })
  }

  const sql = "INSERT INTO materiales_producto (id_producto, id_material, cantidad) VALUES (?,?,?)"

  db.query(sql, [id_producto, id_material, cantidad], (error, result) => {
    if (error) {
      console.error("Error al crear relación material-producto:", error)
      return res.status(500).json({ error: "ERROR: No se pudo crear la relación" })
    }
    const relacion = {
      id_material_producto: result.insertId,
      id_producto: Number.parseInt(id_producto),
      id_material: Number.parseInt(id_material),
      cantidad: Number.parseFloat(cantidad),
    }
    res.status(201).json({
      mensaje: "Relación material-producto creada exitosamente",
      relacion: relacion,
    })
  })
}

//// METODO PUT  ////
const updateProductMaterial = (req, res) => {
  const { id } = req.params
  const { cantidad } = req.body

  // Validación básica
  if (!cantidad) {
    return res.status(400).json({
      error: "Campo obligatorio: cantidad",
    })
  }

  const sql = "UPDATE materiales_producto SET cantidad = ? WHERE id_material_producto = ?"
  db.query(sql, [cantidad, id], (error, result) => {
    if (error) {
      console.error("Error al actualizar relación:", error)
      return res.status(500).json({ error: "ERROR: No se pudo actualizar la relación" })
    }
    if (result.affectedRows == 0) {
      return res.status(404).json({ error: "ERROR: La relación a modificar no existe" })
    }

    res.json({
      mensaje: "Relación actualizada exitosamente",
      relacion: {
        id_material_producto: Number.parseInt(id),
        cantidad: Number.parseFloat(cantidad),
      },
    })
  })
}

//// METODO DELETE ////
// Para borrar una relación
const destroyProductMaterial = (req, res) => {
  const { id } = req.params
  const sql = "DELETE FROM materiales_producto WHERE id_material_producto = ?"
  db.query(sql, [id], (error, result) => {
    if (error) {
      console.error("Error al eliminar relación:", error)
      return res.status(500).json({ error: "ERROR: No se pudo eliminar la relación" })
    }
    if (result.affectedRows == 0) {
      return res.status(404).json({ error: "ERROR: La relación a eliminar no existe" })
    }
    res.json({ mensaje: "Relación eliminada exitosamente" })
  })
}

// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
  allProductMaterials,
  showProductMaterial,
  storeProductMaterial,
  updateProductMaterial,
  destroyProductMaterial,
}
