/// CONTROLADORES DEL MODULO ///

const db = require("../db/db");

//// METODO GET  /////

// Para todos los productos
const allProducts = (req, res) => {
    const sql = "SELECT * FROM productos";
    db.query(sql, (error, rows) => {
        if(error){
            return res.status(500).json({error : "ERROR: No se pudieron obtener los muebles. Intente más tarde por favor."});
        }
        res.json(rows);
    }); 
};

// Para un producto
const showProduct = (req, res) => {
    const {id} = req.params;
    const sql = "SELECT * FROM productos WHERE id_producto = ?";
    db.query(sql,[id], (error, rows) => {
        if(error){
            return res.status(500).json({error : "ERROR: No se pudo obtener el mueble. Intente más tarde por favor"});
        }
        if(rows.length === 0){
            return res.status(404).send({error : "ERROR: No existe el mueble buscado"});
        };
        res.json(rows[0]); 
        // me muestra el elemento en la posicion cero si existe.
    }); 
};

//// METODO POST  ////
const storeProduct = (req, res) => {
    console.log("Archivo recibido:", req.file); // ← SE AGREGA ESTE LOG PARA DEBUG
    console.log("Datos del formulario:", req.body); // ← SE AGREGA ESTE LOG PARA DEBUG

    let imageName = "";

    if(req.file){
        imageName = req.file.filename;
    };

    const { nombre_producto, descripcion_producto, precio, stock, id_categoria } = req.body;
    const imagen_producto = req.file ? req.file.filename : null;

    // Validación básica (no estricta) para campos vacíos
    if (!nombre_producto || !descripcion_producto || !precio || !stock || !id_categoria) {
        return res.status(400).json({
        error: "Por favor, complete todos los campos del formulario.",
        });
    };

    const sql =
        "INSERT INTO productos (nombre_producto, descripcion_producto, precio, stock, id_categoria, imagen_producto) VALUES (?,?,?,?,?,?)";

    db.query(
        sql,
        [nombre_producto, descripcion_producto, precio, stock, id_categoria, imagen_producto],
        (error, result) => {
        if (error) {
            console.error(error)
            return res.status(500).json({
            error: "ERROR: No se pudo agregar el mueble. Intente más tarde por favor",
            });
        }

        const producto = {
            ...req.body,
            id_producto: result.insertId,
            imagen_producto: imagen_producto,
        };

        res.status(201).json({
            mensaje: "✅ Mueble agregado exitosamente",
            id_producto: result.insertId
        });
    });
};

//// METODO PUT  ////
const updateProduct = (req, res) => {
    const {id} = req.params;
    const {nombre_producto, descripcion_producto, precio, stock, id_categoria} = req.body;

    let sql, params

    if (req.file) {
        // Si hay nueva imagen, actualizar todo incluyendo imagen
        sql =
            "UPDATE productos SET nombre_producto = ?, descripcion_producto = ?, precio = ?, stock = ?, id_categoria = ?, imagen_producto = ? WHERE id_producto = ?"
        params = [nombre_producto, descripcion_producto, precio, stock, id_categoria, req.file.filename, id]
        }  else {
        // Si no hay nueva imagen, actualizar solo los otros campos
        sql =
        "UPDATE productos SET nombre_producto = ?, descripcion_producto = ?, precio = ?, stock = ?, id_categoria = ? WHERE id_producto = ?"
        params = [nombre_producto, descripcion_producto, precio, stock, id_categoria, id]
    }

    db.query(sql, params, (error, result) => {
        if (error) {
        return res.status(500).json({ error: "ERROR: No se pudo actualizar el mueble. Intente más tarde por favor" })
        }
        if (result.affectedRows === 0) {
        return res.status(404).send({ error: "ERROR: El mueble a modificar no existe" })
        }

        const producto = { ...req.body, id_producto: id }
        // ← AGREGAR IMAGEN AL RESPONSE SOLO SI SE SUBIÓ UNA NUEVA:
        if (req.file) {
        producto.imagen_producto = req.file.filename
        }

        res.json({ mensaje: "Mueble actualizado exitosamente", producto })
    })
    }


//// METODO DELETE ////
const destroyProduct = (req, res) => {
    const { id } = req.params
    const sql = "DELETE FROM productos WHERE id_producto = ?"

    db.query(sql, [id], (error, result) => {
        if (error) {
        return res.status(500).json({ error: "ERROR: No se pudo eliminar el mueble. Intente más tarde por favor" })
        }
        if (result.affectedRows === 0) {
        return res.status(404).send({ error: "ERROR: El mueble a eliminar no existe" })
        }

        res.json({ mensaje: "Mueble eliminado exitosamente" });
    }); 
};


// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
    allProducts,
    showProduct,
    storeProduct,
    updateProduct,
    destroyProduct
};