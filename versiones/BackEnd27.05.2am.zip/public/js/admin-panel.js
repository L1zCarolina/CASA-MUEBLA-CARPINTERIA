// admin-panel.js - Panel de administración COMPLETO Y FUNCIONAL

document.addEventListener("DOMContentLoaded", () => {
  // Variables globales
  const API_URL = "http://localhost:3001/api"
  let formularioProductoInicializado = false
  const productosSeleccionados = new Set()
  let seccionActual = "dashboard" // ← RECORDAR SECCIÓN ACTUAL

  // Referencias DOM
  const btnLogout = document.getElementById("btn-logout")
  const panelNavButtons = document.querySelectorAll(".panel-nav-btn")
  const panelSections = document.querySelectorAll(".panel-section")

  // Verificar autenticación
  const token = localStorage.getItem("token")
  const usuario = JSON.parse(localStorage.getItem("usuario") || "{}")

  if (!token || usuario.rol !== "admin") {
    window.location.href = "mi-cuenta.html"
    return
  }

  // Headers para peticiones
  function getAuthHeader() {
    return {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    }
  }

  // ← RESTAURAR SECCIÓN ACTIVA AL RECARGAR
  function restaurarSeccionActiva() {
    const seccionGuardada = localStorage.getItem("seccionActiva") || "dashboard"
    cambiarSeccion(seccionGuardada)
  }

  // ← CAMBIAR SECCIÓN Y GUARDAR ESTADO
  function cambiarSeccion(seccion) {
    seccionActual = seccion
    localStorage.setItem("seccionActiva", seccion)

    // Actualizar navegación
    panelNavButtons.forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.section === seccion)
    })

    // Mostrar sección
    panelSections.forEach((sec) => {
      sec.classList.toggle("active", sec.id === seccion)
    })
  }

  // Inicializar panel
  function inicializarPanel() {
    // Logout
    if (btnLogout) {
      btnLogout.addEventListener("click", () => {
        localStorage.removeItem("token")
        localStorage.removeItem("usuario")
        localStorage.removeItem("seccionActiva") // ← LIMPIAR SECCIÓN GUARDADA
        window.location.href = "mi-cuenta.html"
      })
    }

    // ← NAVEGACIÓN MEJORADA
    panelNavButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        cambiarSeccion(btn.dataset.section)
      })
    })

    // ← CARDS CLICKEABLES PARA NAVEGAR
    document.querySelectorAll(".dashboard-card").forEach((card, index) => {
      card.style.cursor = "pointer"
      card.addEventListener("click", () => {
        const secciones = ["usuarios", "productos", "pedidos", "clientes", "proveedores"]
        if (secciones[index]) {
          cambiarSeccion(secciones[index])
        }
      })
    })

    // Inicializar formularios
    inicializarFormularios()

    // Cargar datos
    cargarDatosAPI()

    // ← RESTAURAR SECCIÓN ACTIVA
    restaurarSeccionActiva()
  }

  // ← FUNCIÓN PARA MOSTRAR MENSAJES SIN JSON CRUDO
  function mostrarMensaje(mensaje, tipo = "info") {
    // Buscar contenedor existente o crear uno
    let contenedor = document.querySelector(".mensaje-estado")
    if (!contenedor) {
      contenedor = document.createElement("div")
      contenedor.className = "mensaje-estado"

      // Insertar en la sección activa
      const seccionActiva = document.querySelector(".panel-section.active")
      if (seccionActiva) {
        seccionActiva.insertBefore(contenedor, seccionActiva.firstChild)
      }
    }

    // Limpiar clases y agregar nueva
    contenedor.className = "mensaje-estado"
    contenedor.classList.add(`mensaje-${tipo}`)

    // Mostrar mensaje
    contenedor.textContent = mensaje
    contenedor.style.display = "block"

    // Auto-ocultar
    setTimeout(() => {
      contenedor.style.display = "none"
    }, 5000)
  }

  // ← INICIALIZAR FORMULARIOS UNA SOLA VEZ
  function inicializarFormularios() {
    const formProducto = document.getElementById("formulario-producto-admin")
    if (formProducto && !formularioProductoInicializado) {
      // ← REMOVER LISTENERS EXISTENTES ANTES DE AGREGAR NUEVOS
      formProducto.removeEventListener("submit", manejarEnvioProducto)
      formProducto.addEventListener("submit", manejarEnvioProducto)
      formularioProductoInicializado = true
    }

    // ← INICIALIZAR OTROS FORMULARIOS SEGÚN BD
    inicializarFormularioUsuarios()
    inicializarFormularioClientes()
    inicializarFormularioPedidos()
    inicializarFormularioProveedores()
  }

  // ← MANEJO DE PRODUCTOS MEJORADO SIN DUPLICACIÓN
  function manejarEnvioProducto(e) {
    e.preventDefault()
    e.stopPropagation()

    const form = e.target
    const submitBtn = form.querySelector('button[type="submit"]')

    // Prevenir múltiples envíos
    if (submitBtn.disabled) return

    submitBtn.disabled = true
    const textoOriginal = submitBtn.textContent
    submitBtn.textContent = "Guardando..."

    const formData = new FormData(form)
    const isEditing = form.querySelector('input[name="id_producto"]')?.value

    const url = isEditing ? `${API_URL}/productos/${isEditing}` : `${API_URL}/productos`
    const method = isEditing ? "PUT" : "POST"

    fetch(url, { method, body: formData })
      .then((response) => {
        if (!response.ok) {
          return response.json().then((err) => Promise.reject(err))
        }
        return response.json()
      })
      .then((data) => {
        // ← MOSTRAR MENSAJE LIMPIO (NO JSON)
        const mensaje =
          data.mensaje || (isEditing ? "Producto actualizado exitosamente" : "Producto creado exitosamente")
        mostrarMensaje(`✅ ${mensaje}`, "exito")

        // ← RESETEAR FORMULARIO Y RECARGAR TABLA
        resetearFormularioProducto(form)
        cargarProductos() // ← ESTO CARGA LA TABLA FORMATEADA
      })
      .catch((error) => {
        console.error("Error:", error)
        mostrarMensaje(`❌ Error: ${error.error || error.message || "No se pudo guardar"}`, "error")
      })
      .finally(() => {
        submitBtn.disabled = false
        submitBtn.textContent = textoOriginal
      })
  }

  // ← RESETEAR FORMULARIO CORRECTAMENTE
  function resetearFormularioProducto(form) {
    form.reset()

    // Remover elementos de edición
    const hiddenId = form.querySelector('input[name="id_producto"]')
    if (hiddenId) hiddenId.remove()

    const btnCancelar = form.querySelector(".btn-cancelar")
    if (btnCancelar) btnCancelar.remove()

    const imagenActual = document.getElementById("imagen-actual-container")
    if (imagenActual) imagenActual.remove()

    // Restaurar estado original
    const submitBtn = form.querySelector('button[type="submit"]')
    if (submitBtn) submitBtn.textContent = "Registrar Producto"

    const imagenInput = form.querySelector('input[name="imagen_producto"]')
    if (imagenInput) imagenInput.setAttribute("required", "")
  }

  // ← CARGAR DATOS API
  function cargarDatosAPI() {
    cargarUsuarios()
    cargarProductos()
    cargarPedidos()
    cargarClientes()
    cargarProveedores()
    cargarCategorias()
  }

  // ← CARGAR PRODUCTOS SIN JSON CRUDO
  function cargarProductos() {
    fetch(`${API_URL}/productos`)
      .then((response) => {
        if (!response.ok) throw new Error("Error al cargar productos")
        return response.json()
      })
      .then((productos) => {
        console.log("Productos cargados:", productos)

        // ← VERIFICAR QUE SEA ARRAY Y NO JSON CRUDO
        if (!Array.isArray(productos)) {
          console.error("Respuesta no es array:", productos)
          throw new Error("Respuesta inválida del servidor")
        }

        // ← CARGAR TABLA FORMATEADA
        cargarTablaProductos(productos)

        // Actualizar contador
        const contador = document.querySelector(".dashboard-card:nth-child(2) .count")
        if (contador) contador.textContent = productos.length
      })
      .catch((error) => {
        console.error("Error cargando productos:", error)
        mostrarMensaje("❌ Error al cargar productos", "error")

        // ← MOSTRAR TABLA VACÍA EN CASO DE ERROR
        cargarTablaProductos([])
      })
  }

  // ← TABLA DE PRODUCTOS MEJORADA Y ORGANIZADA
  function cargarTablaProductos(productos) {
    const tabla = document.getElementById("lista-productos")
    if (!tabla) return

    const tbody = tabla.querySelector("tbody")
    const thead = tabla.querySelector("thead")

    // ← CREAR ENCABEZADO MEJORADO
    if (!thead.querySelector(".checkbox-header")) {
      thead.innerHTML = `
        <tr>
          <th class="checkbox-header" style="width: 40px;">
            <input type="checkbox" id="selectAll" onchange="seleccionarTodos()">
          </th>
          <th style="width: 60px;">ID</th>
          <th style="width: 80px;">Imagen</th>
          <th style="width: 150px;">Nombre</th>
          <th style="width: 200px;">Descripción</th>
          <th style="width: 100px;">Precio</th>
          <th style="width: 80px;">Stock</th>
          <th style="width: 100px;">Categoría</th>
          <th style="width: 120px;">Acciones</th>
        </tr>
      `
    }

    // ← AGREGAR BUSCADOR Y FILTROS
    agregarBuscadorYFiltros()

    tbody.innerHTML = ""

    if (productos.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="9" style="text-align: center; padding: 20px; color: #666;">
            No hay productos registrados
          </td>
        </tr>
      `
      return
    }

    productos.forEach((producto) => {
      const tr = document.createElement("tr")
      tr.style.borderBottom = "1px solid #eee"

      // Checkbox
      tr.innerHTML = `
        <td style="text-align: center;">
          <input type="checkbox" class="producto-checkbox" value="${producto.id_producto}" onchange="actualizarSeleccion()">
        </td>
        <td style="font-weight: bold;">${producto.id_producto}</td>
        <td style="text-align: center;">
          ${
            producto.imagen_producto
              ? `<img src="http://localhost:3001/uploads/${producto.imagen_producto}" 
                     alt="Imagen" 
                     style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px; cursor: pointer;"
                     onclick="mostrarImagenGrande('http://localhost:3001/uploads/${producto.imagen_producto}')">`
              : '<span style="color: #999; font-size: 12px;">Sin imagen</span>'
          }
        </td>
        <td style="font-weight: 500;">${producto.nombre_producto}</td>
        <td style="font-size: 13px; color: #666;" title="${producto.descripcion_producto}">
          ${
            producto.descripcion_producto?.length > 50
              ? producto.descripcion_producto.substring(0, 50) + "..."
              : producto.descripcion_producto || "Sin descripción"
          }
        </td>
        <td style="color: #e8491d; font-weight: bold;">$${Number.parseFloat(producto.precio).toFixed(2)}</td>
        <td style="text-align: center;">
          <span style="background: ${producto.stock > 10 ? "#d4edda" : producto.stock > 0 ? "#fff3cd" : "#f8d7da"}; 
                       color: ${producto.stock > 10 ? "#155724" : producto.stock > 0 ? "#856404" : "#721c24"}; 
                       padding: 2px 8px; border-radius: 12px; font-size: 12px;">
            ${producto.stock}
          </span>
        </td>
        <td>${obtenerNombreCategoria(producto.id_categoria)}</td>
        <td style="text-align: center;">
          <button class="btn-icon btn-editar" onclick="editarProducto(${JSON.stringify(producto).replace(/"/g, "&quot;")})" 
                  title="Editar producto">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn-icon btn-eliminar" onclick="eliminarProducto(${producto.id_producto})" 
                  title="Eliminar producto">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      `

      tbody.appendChild(tr)
    })

    // ← ACTUALIZAR BOTÓN ELIMINAR MÚLTIPLES
    actualizarBotonEliminarMultiples()
  }

  // ← AGREGAR BUSCADOR Y FILTROS
  function agregarBuscadorYFiltros() {
    let contenedorFiltros = document.getElementById("filtros-productos")

    if (!contenedorFiltros) {
      contenedorFiltros = document.createElement("div")
      contenedorFiltros.id = "filtros-productos"
      contenedorFiltros.className = "filtros-container"
      contenedorFiltros.innerHTML = `
        <div style="display: flex; gap: 15px; margin-bottom: 20px; align-items: center; flex-wrap: wrap;">
          <div style="flex: 1; min-width: 200px;">
            <input type="text" id="buscarProducto" placeholder="Buscar productos..." 
                   style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 5px;">
          </div>
          <div>
            <select id="filtroCategoria" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 5px;">
              <option value="">Todas las categorías</option>
            </select>
          </div>
          <div>
            <select id="filtroStock" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 5px;">
              <option value="">Todo el stock</option>
              <option value="sin_stock">Sin stock</option>
              <option value="poco_stock">Poco stock (≤10)</option>
              <option value="con_stock">Con stock (>10)</option>
            </select>
          </div>
          <button onclick="limpiarFiltros()" style="padding: 8px 15px; background: #6c757d; color: white; border: none; border-radius: 5px;">
            <i class="fas fa-times"></i> Limpiar
          </button>
        </div>
      `

      // Insertar antes de la tabla
      const tabla = document.getElementById("lista-productos")
      if (tabla) {
        tabla.parentNode.insertBefore(contenedorFiltros, tabla)
      }

      // ← EVENTOS DE FILTROS
      document.getElementById("buscarProducto").addEventListener("input", filtrarProductos)
      document.getElementById("filtroCategoria").addEventListener("change", filtrarProductos)
      document.getElementById("filtroStock").addEventListener("change", filtrarProductos)
    }
  }

  // ← FILTRAR PRODUCTOS
  window.filtrarProductos = () => {
    const busqueda = document.getElementById("buscarProducto").value.toLowerCase()
    const categoria = document.getElementById("filtroCategoria").value
    const stock = document.getElementById("filtroStock").value

    const filas = document.querySelectorAll("#lista-productos tbody tr")

    filas.forEach((fila) => {
      if (fila.cells.length < 9) return // Saltar fila de "no hay productos"

      const nombre = fila.cells[3].textContent.toLowerCase()
      const descripcion = fila.cells[4].textContent.toLowerCase()
      const categoriaProducto = fila.cells[7].textContent
      const stockProducto = Number.parseInt(fila.cells[6].textContent.trim())

      let mostrar = true

      // Filtro de búsqueda
      if (busqueda && !nombre.includes(busqueda) && !descripcion.includes(busqueda)) {
        mostrar = false
      }

      // Filtro de categoría
      if (categoria && categoriaProducto !== categoria) {
        mostrar = false
      }

      // Filtro de stock
      if (stock) {
        switch (stock) {
          case "sin_stock":
            if (stockProducto > 0) mostrar = false
            break
          case "poco_stock":
            if (stockProducto > 10) mostrar = false
            break
          case "con_stock":
            if (stockProducto <= 10) mostrar = false
            break
        }
      }

      fila.style.display = mostrar ? "" : "none"
    })
  }

  // ← LIMPIAR FILTROS
  window.limpiarFiltros = () => {
    document.getElementById("buscarProducto").value = ""
    document.getElementById("filtroCategoria").value = ""
    document.getElementById("filtroStock").value = ""
    filtrarProductos()
  }

  // ← OBTENER NOMBRE DE CATEGORÍA
  function obtenerNombreCategoria(idCategoria) {
    const categorias = {
      1: "Sillas",
      2: "Mesas",
      3: "Muebles de sala",
      4: "Muebles de comedor",
      5: "Muebles de dormitorio",
      6: "Muebles de oficina",
    }
    return categorias[idCategoria] || "Sin categoría"
  }

  // ← FUNCIONES GLOBALES PARA SELECCIÓN MÚLTIPLE
  window.seleccionarTodos = () => {
    const selectAll = document.getElementById("selectAll")
    const checkboxes = document.querySelectorAll(".producto-checkbox")

    checkboxes.forEach((checkbox) => {
      checkbox.checked = selectAll.checked
    })

    actualizarSeleccion()
  }

  window.actualizarSeleccion = () => {
    const checkboxes = document.querySelectorAll(".producto-checkbox:checked")
    productosSeleccionados.clear()

    checkboxes.forEach((checkbox) => {
      productosSeleccionados.add(Number.parseInt(checkbox.value))
    })

    actualizarBotonEliminarMultiples()
  }

  // ← BOTÓN ELIMINAR MÚLTIPLES SOLO VISIBLE CUANDO HAY SELECCIÓN
  function actualizarBotonEliminarMultiples() {
    let btnEliminar = document.getElementById("btnEliminarSeleccionados")

    if (productosSeleccionados.size === 0) {
      // ← OCULTAR BOTÓN SI NO HAY SELECCIÓN
      if (btnEliminar) {
        btnEliminar.style.display = "none"
      }
      return
    }

    if (!btnEliminar) {
      // Crear botón
      btnEliminar = document.createElement("button")
      btnEliminar.id = "btnEliminarSeleccionados"
      btnEliminar.className = "boton-panel"
      btnEliminar.style.backgroundColor = "#dc3545"
      btnEliminar.style.marginTop = "10px"
      btnEliminar.onclick = eliminarProductosSeleccionados

      // Agregar después del formulario
      const form = document.getElementById("formulario-producto-admin")
      if (form) {
        form.parentNode.insertBefore(btnEliminar, form.nextSibling)
      }
    }

    // ← MOSTRAR Y ACTUALIZAR TEXTO
    btnEliminar.style.display = "block"
    btnEliminar.innerHTML = `<i class="fas fa-trash"></i> Eliminar Seleccionados (${productosSeleccionados.size})`
  }

  // ← ELIMINAR MÚLTIPLES PRODUCTOS
  window.eliminarProductosSeleccionados = () => {
    if (productosSeleccionados.size === 0) return

    if (confirm(`¿Estás seguro de eliminar ${productosSeleccionados.size} producto(s)?`)) {
      const promesas = Array.from(productosSeleccionados).map((id) =>
        fetch(`${API_URL}/productos/${id}`, {
          method: "DELETE",
          headers: getAuthHeader(),
        }),
      )

      Promise.all(promesas)
        .then(() => {
          mostrarMensaje(`✅ ${productosSeleccionados.size} producto(s) eliminado(s)`, "exito")
          productosSeleccionados.clear()
          document.getElementById("selectAll").checked = false
          cargarProductos()
        })
        .catch(() => {
          mostrarMensaje("❌ Error al eliminar algunos productos", "error")
        })
    }
  }

  // ← MOSTRAR IMAGEN GRANDE
  window.mostrarImagenGrande = (src) => {
    const modal = document.createElement("div")
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.8); display: flex; justify-content: center; align-items: center;
      z-index: 9999; cursor: pointer;
    `

    const img = document.createElement("img")
    img.src = src
    img.style.cssText = "max-width: 90%; max-height: 90%; border-radius: 10px;"

    modal.appendChild(img)
    modal.onclick = () => document.body.removeChild(modal)
    document.body.appendChild(modal)
  }

  // ← EDITAR PRODUCTO CON BOTÓN CANCELAR FUNCIONAL
  window.editarProducto = (producto) => {
    const form = document.getElementById("formulario-producto-admin")
    if (!form) return

    // Llenar campos
    document.getElementById("nombre_producto_admin").value = producto.nombre_producto
    document.getElementById("descripcion_admin").value = producto.descripcion_producto
    document.getElementById("precio_admin").value = producto.precio
    document.getElementById("stock_admin").value = producto.stock
    document.getElementById("categoria_admin").value = producto.id_categoria

    // Mostrar imagen actual
    if (producto.imagen_producto) {
      mostrarImagenActual(producto.imagen_producto)
    }

    // Hacer imagen opcional
    const imagenInput = document.getElementById("imagen_producto_admin")
    imagenInput.removeAttribute("required")

    // Agregar campo hidden
    let hiddenId = form.querySelector('input[name="id_producto"]')
    if (!hiddenId) {
      hiddenId = document.createElement("input")
      hiddenId.type = "hidden"
      hiddenId.name = "id_producto"
      form.appendChild(hiddenId)
    }
    hiddenId.value = producto.id_producto

    // Cambiar botón
    const submitBtn = form.querySelector('button[type="submit"]')
    submitBtn.textContent = "Actualizar Producto"

    // ← AGREGAR BOTÓN CANCELAR FUNCIONAL
    let btnCancelar = form.querySelector(".btn-cancelar")
    if (!btnCancelar) {
      btnCancelar = document.createElement("button")
      btnCancelar.type = "button"
      btnCancelar.className = "btn-cancelar boton-panel"
      btnCancelar.textContent = "Cancelar"
      btnCancelar.style.backgroundColor = "#6c757d"
      btnCancelar.style.marginLeft = "10px"

      btnCancelar.onclick = () => {
        resetearFormularioProducto(form)
        mostrarMensaje("Edición cancelada", "info")
      }

      submitBtn.parentNode.appendChild(btnCancelar)
    }

    form.scrollIntoView({ behavior: "smooth" })
    mostrarMensaje("Editando producto. Modifica los campos necesarios.", "info")
  }

  // ← MOSTRAR IMAGEN ACTUAL EN EDICIÓN
  function mostrarImagenActual(nombreImagen) {
    let contenedor = document.getElementById("imagen-actual-container")

    if (!contenedor) {
      contenedor = document.createElement("div")
      contenedor.id = "imagen-actual-container"
      contenedor.className = "form-group"

      const imagenInput = document.getElementById("imagen_producto_admin")
      imagenInput.parentNode.insertBefore(contenedor, imagenInput)
    }

    contenedor.innerHTML = `
      <label>Imagen Actual:</label>
      <div style="margin-top: 10px;">
        <img src="http://localhost:3001/uploads/${nombreImagen}" 
             alt="Imagen actual" 
             style="max-width: 150px; border-radius: 5px; cursor: pointer; border: 2px solid #ddd;"
             onclick="mostrarImagenGrande('http://localhost:3001/uploads/${nombreImagen}')">
        <p style="font-size: 12px; color: #666; margin-top: 5px;">
          Deja el campo de imagen vacío para mantener la imagen actual
        </p>
      </div>
    `
  }

  // ← ELIMINAR PRODUCTO INDIVIDUAL
  window.eliminarProducto = (id) => {
    if (confirm("¿Estás seguro de eliminar este producto?")) {
      fetch(`${API_URL}/productos/${id}`, {
        method: "DELETE",
        headers: getAuthHeader(),
      })
        .then((response) => {
          if (!response.ok) throw new Error("Error al eliminar")
          return response.json()
        })
        .then(() => {
          mostrarMensaje("✅ Producto eliminado exitosamente", "exito")
          cargarProductos()
        })
        .catch(() => {
          mostrarMensaje("❌ Error al eliminar producto", "error")
        })
    }
  }

  // ← CARGAR USUARIOS SEGÚN BD
  function cargarUsuarios() {
    fetch(`${API_URL}/usuarios`, { headers: getAuthHeader() })
      .then((r) => (r.ok ? r.json() : Promise.reject("Error al cargar usuarios")))
      .then((usuarios) => {
        cargarTablaGenerica("lista-usuarios", usuarios, [
          "id_usuario",
          "nombre_usuario",
          "email_usuario",
          "rol",
          "fecha_registro",
        ])
        document.querySelector(".dashboard-card:nth-child(1) .count").textContent = usuarios.length
      })
      .catch(console.error)
  }

  // ← CARGAR CLIENTES SEGÚN BD
  function cargarClientes() {
    fetch(`${API_URL}/clientes`, { headers: getAuthHeader() })
      .then((r) => (r.ok ? r.json() : Promise.reject("Error al cargar clientes")))
      .then((clientes) => {
        cargarTablaGenerica("lista-clientes", clientes, [
          "id_cliente",
          "nombre_cliente",
          "apellido_cliente",
          "telefono_cliente",
          "direccion_cliente",
        ])
        document.querySelector(".dashboard-card:nth-child(4) .count").textContent = clientes.length
      })
      .catch(console.error)
  }

  // ← CARGAR PEDIDOS SEGÚN BD
  function cargarPedidos() {
    fetch(`${API_URL}/pedidos`, { headers: getAuthHeader() })
      .then((r) => (r.ok ? r.json() : Promise.reject("Error al cargar pedidos")))
      .then((pedidos) => {
        cargarTablaGenerica("lista-pedidos", pedidos, [
          "id_pedido",
          "id_cliente",
          "fecha_pedido",
          "estado_pedido",
          "total",
        ])
        document.querySelector(".dashboard-card:nth-child(3) .count").textContent = pedidos.length
      })
      .catch(console.error)
  }

  // ← CARGAR PROVEEDORES SEGÚN BD
  function cargarProveedores() {
    fetch(`${API_URL}/proveedores`, { headers: getAuthHeader() })
      .then((r) => (r.ok ? r.json() : Promise.reject("Error al cargar proveedores")))
      .then((proveedores) => {
        cargarTablaGenerica("lista-proveedores", proveedores, [
          "id_proveedor",
          "nombre_proveedor",
          "contacto_nombre",
          "contacto_telefono",
          "contacto_email",
        ])
        document.querySelector(".dashboard-card:nth-child(5) .count").textContent = proveedores.length
      })
      .catch(console.error)
  }

  // ← CARGAR CATEGORÍAS PARA SELECT
  function cargarCategorias() {
    fetch(`${API_URL}/categorias`)
      .then((r) => (r.ok ? r.json() : Promise.reject("Error al cargar categorías")))
      .then((categorias) => {
        // Select de productos
        const selectProducto = document.getElementById("categoria_admin")
        if (selectProducto) {
          selectProducto.innerHTML = '<option value="">Seleccionar categoría</option>'
          categorias.forEach((cat) => {
            const option = document.createElement("option")
            option.value = cat.id_categoria
            option.textContent = cat.nombre_categoria
            selectProducto.appendChild(option)
          })
        }

        // Select de filtros
        const selectFiltro = document.getElementById("filtroCategoria")
        if (selectFiltro) {
          selectFiltro.innerHTML = '<option value="">Todas las categorías</option>'
          categorias.forEach((cat) => {
            const option = document.createElement("option")
            option.value = cat.nombre_categoria
            option.textContent = cat.nombre_categoria
            selectFiltro.appendChild(option)
          })
        }
      })
      .catch(console.error)
  }

  // ← TABLA GENÉRICA PARA OTRAS ENTIDADES
  function cargarTablaGenerica(tablaId, datos, campos) {
    const tabla = document.getElementById(tablaId)
    if (!tabla) return

    const tbody = tabla.querySelector("tbody")
    tbody.innerHTML = ""

    if (datos.length === 0) {
      tbody.innerHTML = `
        <tr>
          <td colspan="${campos.length + 1}" style="text-align: center; padding: 20px; color: #666;">
            No hay registros
          </td>
        </tr>
      `
      return
    }

    datos.forEach((item) => {
      const tr = document.createElement("tr")

      campos.forEach((campo) => {
        const td = document.createElement("td")
        let valor = item[campo]

        // Formatear valores especiales
        if (campo.includes("fecha") && valor) {
          valor = new Date(valor).toLocaleDateString()
        } else if (campo === "total" && valor) {
          valor = `$${Number.parseFloat(valor).toFixed(2)}`
        }

        td.textContent = valor || "N/A"
        tr.appendChild(td)
      })

      // Acciones
      const tdAcciones = document.createElement("td")
      tdAcciones.innerHTML = `
        <button class="btn-icon btn-editar" title="Editar">
          <i class="fas fa-edit"></i>
        </button>
        <button class="btn-icon btn-eliminar" title="Eliminar">
          <i class="fas fa-trash"></i>
        </button>
      `
      tr.appendChild(tdAcciones)

      tbody.appendChild(tr)
    })
  }

  // ← INICIALIZAR OTROS FORMULARIOS (PLACEHOLDER)
  function inicializarFormularioUsuarios() {
    // Implementar según necesidades
  }

  function inicializarFormularioClientes() {
    // Implementar según necesidades
  }

  function inicializarFormularioPedidos() {
    // Implementar según necesidades
  }

  function inicializarFormularioProveedores() {
    // Implementar según necesidades
  }

  // Inicializar todo
  inicializarPanel()
})
