-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS casa_muebla_carpinteria;
USE casa_muebla_carpinteria;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(100) NOT NULL,
  email_usuario VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  foto_perfil VARCHAR(255),
  rol ENUM('admin', 'usuario') DEFAULT 'usuario'
);

-- Tabla de categorías
CREATE TABLE IF NOT EXISTS categorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  precio DECIMAL(10,2) NOT NULL,
  stock INT DEFAULT 0,
  categoria INT,
  imagen VARCHAR(255),
  FOREIGN KEY (categoria) REFERENCES categorias(id) ON DELETE SET NULL
);

-- Tabla de clientes
CREATE TABLE IF NOT EXISTS clientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  telefono VARCHAR(20),
  direccion TEXT,
  usuario_id INT,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id_usuario) ON DELETE SET NULL
);

-- Tabla de pedidos
CREATE TABLE IF NOT EXISTS pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('pendiente', 'en_proceso', 'completado', 'cancelado') DEFAULT 'pendiente',
  total DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

-- Tabla de detalles de pedidos
CREATE TABLE IF NOT EXISTS detalles_pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  producto_id INT NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE
);

-- Tabla de proveedores
CREATE TABLE IF NOT EXISTS proveedores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  contacto VARCHAR(100),
  email VARCHAR(100),
  telefono VARCHAR(20),
  direccion TEXT
);

-- Tabla de materiales
CREATE TABLE IF NOT EXISTS materiales (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT,
  unidad_medida VARCHAR(50) NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  stock DECIMAL(10,2) DEFAULT 0,
  proveedor_id INT,
  FOREIGN KEY (proveedor_id) REFERENCES proveedores(id) ON DELETE SET NULL
);

-- Tabla de relación producto-material
CREATE TABLE IF NOT EXISTS producto_material (
  id INT AUTO_INCREMENT PRIMARY KEY,
  producto_id INT NOT NULL,
  material_id INT NOT NULL,
  cantidad DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (producto_id) REFERENCES productos(id) ON DELETE CASCADE,
  FOREIGN KEY (material_id) REFERENCES materiales(id) ON DELETE CASCADE
);

-- Tabla de cotizaciones
CREATE TABLE IF NOT EXISTS cotizaciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  tipo_mueble VARCHAR(100) NOT NULL,
  descripcion TEXT NOT NULL,
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  estado ENUM('pendiente', 'procesada', 'rechazada') DEFAULT 'pendiente',
  FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
);

-- Insertar datos de prueba para categorías
INSERT INTO categorias (nombre, descripcion) VALUES
('Muebles de sala', 'Muebles para la sala de estar'),
('Muebles de comedor', 'Mesas, sillas y otros muebles para el comedor'),
('Muebles de dormitorio', 'Camas, armarios y otros muebles para el dormitorio'),
('Muebles de oficina', 'Escritorios, sillas y otros muebles para oficina');

-- Insertar un usuario administrador
INSERT INTO usuarios (nombre_usuario, email_usuario, password, rol) VALUES
('Admin', 'admin@casamuebla.com', '$2a$10$XZxXKrA.77OxRWyVv8ypeOoRLpRqyVUFUaUKIZkxQq2xR0yvzKOXi', 'admin');
-- La contraseña es 'admin123' (hasheada con bcrypt)