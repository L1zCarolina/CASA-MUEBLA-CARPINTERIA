// crear-producto.js - Manejo del formulario de creación de productos

document.addEventListener("DOMContentLoaded", function () {
  // Referencia al formulario y al contenedor de mensajes
  const form = document.getElementById("formulario-producto");
  const mensaje = document.getElementById("mensaje-estado");
  const API_URL = "http://localhost:3001/api/productos";

  // Evento para el submit del formulario
  form.addEventListener("submit", function (e) {
    e.preventDefault(); // Evita recarga de la página
    const submitBtn = form.querySelector("button[type='submit']");
    submitBtn.disabled = true;

    const fd = new FormData(form); // Crea FormData con los campos del formulario

    fetch(API_URL, {
      method: "POST",
      body: fd // No agregamos headers para que el navegador maneje multipart/form-data
    })
      .then(res => res.ok ? res.json() : res.json().then(err => Promise.reject(err)))
      .then(data => {
        // Mensaje de éxito
        mensaje.textContent = "✅ Producto creado con éxito";
        mensaje.className = "mensaje-estado success";
        mensaje.style.color = "green";
        form.reset();
        document.getElementById("imagen-preview").innerHTML = ""; // limpia vista previa
      })
      .catch(err => {
        // Mostrar errores de validación si existen
        if (err.error) {
          mensaje.textContent = "❌ " + err.error;
        } else if (err.errors) {
          const errores = err.errors.map(e => e.msg).join("\n");
          mensaje.textContent = "❌ Errores de validación:\n" + errores;
        } else {
          mensaje.textContent = "❌ Error al guardar el producto.";
        }

        mensaje.className = "mensaje-estado error";
        mensaje.style.color = "red";
        console.error(err);
      })
      .finally(() => {
        submitBtn.disabled = false;
      });
  });

  // Vista previa de imagen al seleccionar archivo
  document.getElementById("imagen_producto").addEventListener("change", function () {
    const preview = document.getElementById("imagen-preview");
    preview.innerHTML = "";
  
    const file = this.files[0];
    if (file) {
      // Validación de tamaño máximo: 5MB
      if (file.size > 5 * 1024 * 1024) {
        alert("La imagen supera los 5MB. Por favor, elige una más liviana.");
        this.value = ""; // limpia el input
        return;
      }
  
      const img = document.createElement("img");
      img.src = URL.createObjectURL(file);
      img.style.maxWidth = "150px";
      img.onload = () => URL.revokeObjectURL(img.src);
      preview.appendChild(img);
    }
  });
});
