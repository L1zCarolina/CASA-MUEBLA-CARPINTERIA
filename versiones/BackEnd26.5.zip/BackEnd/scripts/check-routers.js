const fs = require('fs');
const path = require('path');

// Directorio donde se encuentran los routers
const routersDir = path.join(__dirname, '..', 'routers');

// Función para verificar un router
function checkRouter(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    
    // Verificar si hay importaciones redundantes
    const authMiddlewareImports = content.match(/require$$['"]\.\.\/middlewares\/auth\.middleware['"]$$/g);
    if (authMiddlewareImports && authMiddlewareImports.length > 1) {
      console.log(`[ADVERTENCIA] ${path.basename(filePath)} tiene múltiples importaciones de auth.middleware`);
    }
    
    // Verificar si se está usando authMiddleware y verifyToken al mismo tiempo
    const usesAuthMiddleware = content.includes('authMiddleware');
    const usesVerifyToken = content.includes('verifyToken');
    if (usesAuthMiddleware && usesVerifyToken) {
      console.log(`[ADVERTENCIA] ${path.basename(filePath)} usa tanto authMiddleware como verifyToken`);
    }
    
    // Verificar si hay rutas que usan objetos en lugar de funciones
    const routeDefinitions = content.match(/router\.(get|post|put|delete)$$[^)]+$$/g);
    if (routeDefinitions) {
      for (const route of routeDefinitions) {
        if (route.includes('{') || route.includes('object')) {
          console.log(`[ERROR] ${path.basename(filePath)} tiene una ruta que podría estar usando un objeto en lugar de una función: ${route}`);
        }
      }
    }
    
    console.log(`[OK] ${path.basename(filePath)} verificado`);
  } catch (error) {
    console.error(`[ERROR] No se pudo verificar ${path.basename(filePath)}: ${error.message}`);
  }
}

// Verificar todos los routers
fs.readdir(routersDir, (err, files) => {
  if (err) {
    console.error(`Error al leer el directorio de routers: ${err.message}`);
    return;
  }
  
  console.log(`Verificando ${files.length} archivos de router...`);
  
  files.forEach(file => {
    if (file.endsWith('.router.js')) {
      const filePath = path.join(routersDir, file);
      checkRouter(filePath);
    }
  });
  
  console.log('Verificación completada.');
});