const fs = require('fs');
const path = require('path');

// Directorio donde se encuentran los routers
const routersDir = path.join(__dirname, '..', 'routers');

// Función para verificar un router en detalle
function checkRouterDetailed(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    const fileName = path.basename(filePath);
    
    console.log(`\n=== Analizando ${fileName} ===`);
    
    // Verificar importaciones
    const imports = {};
    const importLines = [];
    
    lines.forEach((line, index) => {
      if (line.includes('require(') || line.includes('import ')) {
        importLines.push({ line, lineNumber: index + 1 });
        
        // Extraer el nombre de la variable y el módulo
        const match = line.match(/(const|let|var)\s+(\{[^}]+\}|\w+)\s*=\s*require$$['"](.*)['"]$$/);
        if (match) {
          const [, , variable, module] = match;
          imports[variable] = { module, lineNumber: index + 1 };
          console.log(`Importación en línea ${index + 1}: ${variable} desde ${module}`);
        }
      }
    });
    
    // Verificar rutas
    const routeLines = [];
    lines.forEach((line, index) => {
      if (line.includes('router.') && (line.includes('.get(') || line.includes('.post(') || line.includes('.put(') || line.includes('.delete('))) {
        routeLines.push({ line, lineNumber: index + 1 });
        
        // Analizar los parámetros de la ruta
        const routeMatch = line.match(/router\.(get|post|put|delete)$$[^)]+$$/);
        if (routeMatch) {
          const routeStr = routeMatch[0];
          console.log(`Ruta en línea ${index + 1}: ${routeStr}`);
          
          // Extraer los parámetros
          const paramsMatch = routeStr.match(/router\.\w+$$([^)]+)$$/);
          if (paramsMatch) {
            const params = paramsMatch[1].split(',').map(p => p.trim());
            console.log(`  Parámetros: ${params.join(', ')}`);
            
            // Verificar cada parámetro
            params.forEach((param, i) => {
              if (param.includes('{') || param.includes('object')) {
                console.log(`  [ERROR] El parámetro ${i + 1} parece ser un objeto: ${param}`);
              }
              
              // Verificar si el parámetro es una variable que no está importada
              if (!param.startsWith('"') && !param.startsWith("'") && !param.startsWith('/') && !param.includes('.')) {
                const paramName = param.trim();
                let found = false;
                
                for (const [importVar, importInfo] of Object.entries(imports)) {
                  if (importVar === paramName || (importVar.includes('{') && importVar.includes(paramName))) {
                    found = true;
                    break;
                  }
                }
                
                if (!found && !['next', 'req', 'res'].includes(paramName)) {
                  console.log(`  [ADVERTENCIA] El parámetro "${paramName}" no parece estar importado correctamente`);
                }
              }
            });
          }
        }
      }
    });
    
    // Verificar exportaciones
    const exportLines = [];
    lines.forEach((line, index) => {
      if (line.includes('module.exports') || line.includes('export ')) {
        exportLines.push({ line, lineNumber: index + 1 });
        console.log(`Exportación en línea ${index + 1}: ${line.trim()}`);
      }
    });
    
    console.log(`\nResumen para ${fileName}:`);
    console.log(`- ${importLines.length} importaciones`);
    console.log(`- ${routeLines.length} rutas`);
    console.log(`- ${exportLines.length} exportaciones`);
    
    return {
      fileName,
      imports: importLines,
      routes: routeLines,
      exports: exportLines,
      hasErrors: routeLines.some(r => r.line.includes('{') || r.line.includes('object'))
    };
  } catch (error) {
    console.error(`[ERROR] No se pudo verificar ${path.basename(filePath)}: ${error.message}`);
    return { fileName: path.basename(filePath), hasErrors: true, error: error.message };
  }
}

// Verificar todos los routers
fs.readdir(routersDir, (err, files) => {
  if (err) {
    console.error(`Error al leer el directorio de routers: ${err.message}`);
    return;
  }
  
  console.log(`Verificando ${files.length} archivos de router en detalle...`);
  
  const results = [];
  
  files.forEach(file => {
    if (file.endsWith('.router.js')) {
      const filePath = path.join(routersDir, file);
      const result = checkRouterDetailed(filePath);
      results.push(result);
    }
  });
  
  console.log('\n=== Resumen General ===');
  const filesWithErrors = results.filter(r => r.hasErrors);
  console.log(`Total de archivos con posibles errores: ${filesWithErrors.length}`);
  
  if (filesWithErrors.length > 0) {
    console.log('\nArchivos con posibles errores:');
    filesWithErrors.forEach(f => {
      console.log(`- ${f.fileName}`);
    });
  }
  
  console.log('\nVerificación detallada completada.');
});