    // upload.productos.middleware.js - Middleware de subida de imágenes de productos
    const multer = require("multer");
    const path = require("path");

    // Configuración de almacenamiento
    const storage = multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, 'uploads'); // Carpeta donde se guardan las imágenes
        },
        filename: (req, file, cb) => {
            cb(null, Date.now() + path.extname(file.originalname)); // Nombre con timestamp
        },
    });

    // Configuración del middleware de subida sin restricciones estrictas
    const uploadProductImage = multer({
    storage,
        fileFilter: (req, file, cb) => {
            // Acepta cualquier imagen básica
            const tiposPermitidos = /jpg|jpeg|png|gif/;
            const esValido = tiposPermitidos.test(file.mimetype) || tiposPermitidos.test(path.extname(file.originalname).toLowerCase());
            cb(null, esValido); // true = permitir
        },
        limits: { fileSize: 10 * 1024 * 1024 }, // hasta 10MB
    });

    module.exports = uploadProductImage;
