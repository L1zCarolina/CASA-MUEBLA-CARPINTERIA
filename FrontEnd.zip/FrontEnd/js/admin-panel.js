// admin-panel.js - Funcionalidad para el panel de administración

document.addEventListener('DOMContentLoaded', function() {
  // Referencias a elementos del DOM
  const btnLogout = document.getElementById('btn-logout');
  const panelNavButtons = document.querySelectorAll('.panel-nav-btn');
  const panelSections = document.querySelectorAll('.panel-section');
  
  // URL base de la API
  const API_URL = 'http://localhost:3001/api';
  
  // Verificar si el usuario está autenticado
  const token = localStorage.getItem('token');
  const usuario = JSON.parse(localStorage.getItem('usuario') || '{}');
  
  if (!token || usuario.rol !== 'admin') {
      // Redireccionar a la página de inicio de sesión si no hay token o no es admin
      window.location.href = 'mi-cuenta.html';
      return;
  }
  
  // Función para crear el encabezado de autorización
  function getAuthHeader() {
      return {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
      };
  }
  
  // Verificar que el token sigue siendo válido
  fetch(`${API_URL}/auth/protected`, {
      headers: getAuthHeader()
  })
  .then(response => {
      if (!response.ok) {
          throw new Error('Token inválido');
      }
      
      // Si el token es válido, continuar con la carga de la página
      inicializarPanel();
  })
  .catch(error => {
      console.error('Error de autenticación:', error);
      // Redireccionar a la página de inicio de sesión
      localStorage.removeItem('token');
      localStorage.removeItem('usuario');
      window.location.href = 'mi-cuenta.html';
  });
  
  // Función para inicializar el panel
  function inicializarPanel() {
      // Evento de cierre de sesión
      if (btnLogout) {
          btnLogout.addEventListener('click', function() {
              // Eliminar token y datos de usuario
              localStorage.removeItem('token');
              localStorage.removeItem('usuario');
              // Redireccionar a la página de inicio de sesión
              window.location.href = 'mi-cuenta.html';
          });
      }
      
      // Navegación entre secciones del panel
      panelNavButtons.forEach(button => {
          button.addEventListener('click', function() {
              // Remover clase active de todos los botones
              panelNavButtons.forEach(btn => btn.classList.remove('active'));
              // Añadir clase active al botón clickeado
              this.classList.add('active');
              
              // Ocultar todas las secciones
              panelSections.forEach(section => section.classList.remove('active'));
              
              // Mostrar la sección correspondiente
              const sectionId = this.getAttribute('data-section');
              document.getElementById(sectionId).classList.add('active');
          });
      });
      
      // Cargar datos desde la API
      cargarDatosAPI();
  }
  
  // Función para cargar datos desde la API
  function cargarDatosAPI() {
      // Cargar datos de usuarios
      fetch(`${API_URL}/usuarios`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar usuarios');
          return response.json();
      })
      .then(data => {
          cargarTabla('lista-usuarios', data, ['id_usuario', 'nombre_usuario', 'email_usuario', 'rol']);
          document.querySelector('.dashboard-card:nth-child(1) .count').textContent = data.length;
      })
      .catch(error => {
          console.error('Error al cargar usuarios:', error);
          // Si hay error, cargar datos de prueba
          cargarDatosDePrueba();
      });
      
      // Cargar datos de productos
      fetch(`${API_URL}/productos`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar productos');
          return response.json();
      })
      .then(data => {
          cargarTabla('lista-productos', data, ['id', 'nombre', 'descripcion', 'precio', 'stock']);
          document.querySelector('.dashboard-card:nth-child(2) .count').textContent = data.length;
      })
      .catch(error => {
          console.error('Error al cargar productos:', error);
      });
      
      // Cargar datos de pedidos
      fetch(`${API_URL}/pedidos`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar pedidos');
          return response.json();
      })
      .then(data => {
          // Transformar los datos para mostrar el nombre del cliente en lugar del ID
          const pedidosPromises = data.map(pedido => {
              return fetch(`${API_URL}/clientes/${pedido.cliente_id}`, {
                  headers: getAuthHeader()
              })
              .then(response => response.json())
              .then(cliente => {
                  return {
                      id: pedido.id,
                      cliente: `${cliente.nombre} ${cliente.apellido}`,
                      fecha: new Date(pedido.fecha_creacion || Date.now()).toLocaleDateString(),
                      estado: pedido.estado,
                      total: pedido.total
                  };
              });
          });
          
          return Promise.all(pedidosPromises);
      })
      .then(pedidosConClientes => {
          cargarTabla('lista-pedidos', pedidosConClientes, ['id', 'cliente', 'fecha', 'estado', 'total']);
          document.querySelector('.dashboard-card:nth-child(3) .count').textContent = pedidosConClientes.length;
      })
      .catch(error => {
          console.error('Error al cargar pedidos:', error);
      });
      
      // Cargar datos de clientes
      fetch(`${API_URL}/clientes`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar clientes');
          return response.json();
      })
      .then(data => {
          // Transformar los datos para mostrar nombre completo
          const clientesFormateados = data.map(cliente => ({
              id: cliente.id,
              nombre: `${cliente.nombre} ${cliente.apellido}`,
              email: cliente.email,
              telefono: cliente.telefono
          }));
          
          cargarTabla('lista-clientes', clientesFormateados, ['id', 'nombre', 'email', 'telefono']);
          document.querySelector('.dashboard-card:nth-child(4) .count').textContent = data.length;
          
          // Cargar opciones en el select de clientes para pedidos
          const selectClientes = document.getElementById('id_cliente');
          if (selectClientes) {
              selectClientes.innerHTML = '<option value="">Seleccionar cliente</option>';
              data.forEach(cliente => {
                  const option = document.createElement('option');
                  option.value = cliente.id;
                  option.textContent = `${cliente.nombre} ${cliente.apellido}`;
                  selectClientes.appendChild(option);
              });
          }
      })
      .catch(error => {
          console.error('Error al cargar clientes:', error);
      });
      
      // Cargar datos de proveedores
      fetch(`${API_URL}/proveedores`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar proveedores');
          return response.json();
      })
      .then(data => {
          cargarTabla('lista-proveedores', data, ['id', 'nombre', 'email', 'telefono', 'contacto']);
          document.querySelector('.dashboard-card:nth-child(5) .count').textContent = data.length;
      })
      .catch(error => {
          console.error('Error al cargar proveedores:', error);
      });
          
      // Cargar datos de categorías para el select de productos
      fetch(`${API_URL}/categorias`, {
          headers: getAuthHeader()
      })
      .then(response => {
          if (!response.ok) throw new Error('Error al cargar categorías');
          return response.json();
      })
      .then(data => {
          const selectCategoria = document.getElementById('categoria');
          if (selectCategoria) {
              selectCategoria.innerHTML = '<option value="">Seleccionar categoría</option>';
              data.forEach(categoria => {
                  const option = document.createElement('option');
                  option.value = categoria.id;
                  option.textContent = categoria.nombre;
                  selectCategoria.appendChild(option);
              });
          }
      })
      .catch(error => {
          console.error('Error al cargar categorías:', error);
      });
  }
  
  // Función para cargar datos de prueba en caso de que la API no esté disponible
  function cargarDatosDePrueba() {
      // Datos de prueba para usuarios
      const usuarios = [
          { id_usuario: 1, nombre_usuario: 'Admin', email_usuario: 'admin@casamuebla.com', rol: 'admin' },
          { id_usuario: 2, nombre_usuario: 'Juan Pérez', email_usuario: 'juan@ejemplo.com', rol: 'empleado' },
          { id_usuario: 3, nombre_usuario: 'María López', email_usuario: 'maria@ejemplo.com', rol: 'cliente' }
      ];
      
      // Datos de prueba para productos
      const productos = [
          { id: 1, nombre: 'Mesa de Roble', descripcion: 'Mesa de comedor de roble macizo', precio: 1200, stock: 5 },
          { id: 2, nombre: 'Silla Moderna', descripcion: 'Silla de diseño contemporáneo', precio: 350, stock: 12 },
          { id: 3, nombre: 'Armario Empotrado', descripcion: 'Armario a medida para dormitorio', precio: 2500, stock: 3 }
      ];
      
      // Datos de prueba para clientes
      const clientes = [
          { id: 1, nombre: 'Carlos Rodríguez', email: 'carlos@ejemplo.com', telefono: '123-456-7890' },
          { id: 2, nombre: 'Ana Martínez', email: 'ana@ejemplo.com', telefono: '098-765-4321' },
          { id: 3, nombre: 'Luis Sánchez', email: 'luis@ejemplo.com', telefono: '555-123-4567' }
      ];
      
      // Datos de prueba para pedidos
      const pedidos = [
          { id: 1, cliente: 'Carlos Rodríguez', fecha: '2024-03-15', estado: 'Pendiente', total: 1550 },
          { id: 2, cliente: 'Ana Martínez', fecha: '2024-03-10', estado: 'En Proceso', total: 2850 },
          { id: 3, cliente: 'Luis Sánchez', fecha: '2024-03-05', estado: 'Completado', total: 3500 }
      ];
      
      // Datos de prueba para proveedores
      const proveedores = [
          { id: 1, nombre: 'Maderas del Sur', email: 'info@maderasdelsur.com', telefono: '111-222-3333', contacto: 'Juan Maderas' },
          { id: 2, nombre: 'Herrajes Modernos', email: 'ventas@herrajesmodernos.com', telefono: '444-555-6666', contacto: 'Ana Herrajes' },
          { id: 3, nombre: 'Vidrios y Cristales', email: 'contacto@vidriosycristales.com', telefono: '777-888-9999', contacto: 'Pedro Vidrio' }
      ];
      
      // Cargar datos en las tablas
      cargarTabla('lista-usuarios', usuarios, ['id_usuario', 'nombre_usuario', 'email_usuario', 'rol']);
      cargarTabla('lista-productos', productos, ['id', 'nombre', 'descripcion', 'precio', 'stock']);
      cargarTabla('lista-clientes', clientes, ['id', 'nombre', 'email', 'telefono']);
      cargarTabla('lista-pedidos', pedidos, ['id', 'cliente', 'fecha', 'estado', 'total']);
      cargarTabla('lista-proveedores', proveedores, ['id', 'nombre', 'email', 'telefono', 'contacto']);
      
      // Actualizar contadores en el dashboard
      document.querySelector('.dashboard-card:nth-child(1) .count').textContent = usuarios.length;
      document.querySelector('.dashboard-card:nth-child(2) .count').textContent = productos.length;
      document.querySelector('.dashboard-card:nth-child(3) .count').textContent = pedidos.length;
      document.querySelector('.dashboard-card:nth-child(4) .count').textContent = clientes.length;
      document.querySelector('.dashboard-card:nth-child(5) .count').textContent = proveedores.length;
      
      // Cargar opciones en el select de clientes para pedidos
      const selectClientes = document.getElementById('id_cliente');
      if (selectClientes) {
          selectClientes.innerHTML = '<option value="">Seleccionar cliente</option>';
          clientes.forEach(cliente => {
              const option = document.createElement('option');
              option.value = cliente.id;
              option.textContent = cliente.nombre;
              selectClientes.appendChild(option);
          });
      }
  }
  
  // Función para cargar datos en una tabla
  function cargarTabla(tablaId, datos, campos) {
      const tabla = document.getElementById(tablaId);
      if (!tabla) return;
      
      const tbody = tabla.querySelector('tbody');
      tbody.innerHTML = '';
      
      datos.forEach(item => {
          const tr = document.createElement('tr');
          
          // Crear celdas para cada campo
          campos.forEach(campo => {
              const td = document.createElement('td');
              td.textContent = item[campo] !== undefined ? item[campo] : '';
              tr.appendChild(td);
          });
          
          // Crear celda para acciones
          const tdAcciones = document.createElement('td');
          tdAcciones.className = 'acciones';
          
          const btnEditar = document.createElement('button');
          btnEditar.className = 'btn-accion btn-editar';
          btnEditar.innerHTML = '<i class="fas fa-edit"></i>';
          btnEditar.title = 'Editar';
          btnEditar.addEventListener('click', function() {
              editarElemento(tablaId, item);
          });
          
          const btnEliminar = document.createElement('button');
          btnEliminar.className = 'btn-accion btn-eliminar';
          btnEliminar.innerHTML = '<i class="fas fa-trash-alt"></i>';
          btnEliminar.title = 'Eliminar';
          btnEliminar.addEventListener('click', function() {
              eliminarElemento(tablaId, item);
          });
          
          tdAcciones.appendChild(btnEditar);
          tdAcciones.appendChild(btnEliminar);
          tr.appendChild(tdAcciones);
          
          tbody.appendChild(tr);
      });
  }
  
  // Función para editar un elemento
  function editarElemento(tablaId, item) {
      let endpoint, formId, idField;
      
      switch(tablaId) {
          case 'lista-usuarios':
              endpoint = 'usuarios';
              formId = 'formulario-usuario';
              idField = 'id_usuario';
              
              document.getElementById('nombre_usuario').value = item.nombre_usuario;
              document.getElementById('email_usuario').value = item.email_usuario;
              document.getElementById('rol_usuario').value = item.rol;
              break;
              
          case 'lista-productos':
              endpoint = 'productos';
              formId = 'formulario-producto';
              idField = 'id';
              
              document.getElementById('nombre_producto').value = item.nombre;
              document.getElementById('descripcion').value = item.descripcion;
              document.getElementById('precio').value = item.precio;
              document.getElementById('stock').value = item.stock;
              document.getElementById('categoria').value = item.categoria;
              break;
              
          case 'lista-clientes':
              endpoint = 'clientes';
              formId = 'formulario-cliente';
              idField = 'id';
              
              // Separar nombre y apellido
              const nombreCompleto = item.nombre.split(' ');
              const nombre = nombreCompleto[0];
              const apellido = nombreCompleto.slice(1).join(' ');
              
              document.getElementById('nombre_cliente').value = nombre;
              document.getElementById('apellido_cliente').value = apellido;
              document.getElementById('email_cliente').value = item.email;
              document.getElementById('telefono_cliente').value = item.telefono;
              document.getElementById('direccion_cliente').value = item.direccion || '';
              break;
              
          case 'lista-pedidos':
              endpoint = 'pedidos';
              formId = 'formulario-pedido';
              idField = 'id';
              
              document.getElementById('id_cliente').value = item.cliente_id;
              document.getElementById('estado_pedido').value = item.estado;
              break;
              
          case 'lista-proveedores':
              endpoint = 'proveedores';
              formId = 'formulario-proveedor';
              idField = 'id';
              
              document.getElementById('nombre_proveedor').value = item.nombre;
              document.getElementById('email_proveedor').value = item.email;
              document.getElementById('telefono_proveedor').value = item.telefono;
              document.getElementById('direccion_proveedor').value = item.direccion || '';
              break;
      }
      
      // Cambiar el comportamiento del formulario para actualizar en lugar de crear
      const formulario = document.getElementById(formId);
      if (formulario) {
          // Guardar la función original del evento submit
          const originalSubmitHandler = formulario.onsubmit;
          
          // Crear un campo oculto para el ID
          let idInput = formulario.querySelector(`input[name="${idField}"]`);
          if (!idInput) {
              idInput = document.createElement('input');
              idInput.type = 'hidden';
              idInput.name = idField;
              formulario.appendChild(idInput);
          }
          idInput.value = item[idField];
          
          // Cambiar el texto del botón
          const submitButton = formulario.querySelector('button[type="submit"]');
          if (submitButton) {
              submitButton.textContent = 'Actualizar';
          }
          
          // Cambiar el evento submit
          formulario.onsubmit = function(e) {
              e.preventDefault();
              
              const formData = new FormData(this);
              
              // Si el formulario incluye un archivo, usar FormData directamente
              if (formData.has('imagen') || formData.has('foto_perfil')) {
                  fetch(`${API_URL}/${endpoint}/${item[idField]}`, {
                      method: 'PUT',
                      headers: {
                          'Authorization': `Bearer ${token}`
                      },
                      body: formData
                  })
                  .then(response => {
                      if (!response.ok) throw new Error('Error al actualizar');
                      return response.json();
                  })
                  .then(data => {
                      alert('Actualizado correctamente');
                      
                      // Restaurar el formulario
                      this.reset();
                      if (submitButton) {
                          submitButton.textContent = 'Registrar';
                      }
                      this.onsubmit = originalSubmitHandler;
                      
                      // Recargar datos
                      cargarDatosAPI();
                  })
                  .catch(error => {
                      console.error('Error:', error);
                      alert('Error al actualizar: ' + error.message);
                  });
              } else {
                  // Si no hay archivos, convertir FormData a JSON
                  const formDataObj = {};
                  formData.forEach((value, key) => {
                      formDataObj[key] = value;
                  });
                  
                  fetch(`${API_URL}/${endpoint}/${item[idField]}`, {
                      method: 'PUT',
                      headers: getAuthHeader(),
                      body: JSON.stringify(formDataObj)
                  })
                  .then(response => {
                      if (!response.ok) throw new Error('Error al actualizar');
                      return response.json();
                  })
                  .then(data => {
                      alert('Actualizado correctamente');
                      
                      // Restaurar el formulario
                      this.reset();
                      if (submitButton) {
                          submitButton.textContent = 'Registrar';
                      }
                      this.onsubmit = originalSubmitHandler;
                      
                      // Recargar datos
                      cargarDatosAPI();
                  })
                  .catch(error => {
                      console.error('Error:', error);
                      alert('Error al actualizar: ' + error.message);
                  });
              }
          };
      }
  }
  
  // Función para eliminar un elemento
  function eliminarElemento(tablaId, item) {
      let endpoint, idField;
      
      switch(tablaId) {
          case 'lista-usuarios':
              endpoint = 'usuarios';
              idField = 'id_usuario';
              break;
              
          case 'lista-productos':
              endpoint = 'productos';
              idField = 'id';
              break;
              
          case 'lista-clientes':
              endpoint = 'clientes';
              idField = 'id';
              break;
              
          case 'lista-pedidos':
              endpoint = 'pedidos';
              idField = 'id';
              break;
              
          case 'lista-proveedores':
              endpoint = 'proveedores';
              idField = 'id';
              break;
      }
      
      if (confirm(`¿Estás seguro de eliminar este elemento?`)) {
          fetch(`${API_URL}/${endpoint}/${item[idField]}`, {
              method: 'DELETE',
              headers: getAuthHeader()
          })
          .then(response => {
              if (!response.ok) throw new Error('Error al eliminar');
              return response.json();
          })
          .then(data => {
              alert('Eliminado correctamente');
              cargarDatosAPI();
          })
          .catch(error => {
              console.error('Error:', error);
              alert('Error al eliminar: ' + error.message);
          });
      }
  }
  
  // Manejar envío de formularios
  const formularios = [
      { id: 'formulario-usuario', mensaje: 'Usuario registrado correctamente', endpoint: 'usuarios' },
      { id: 'formulario-producto', mensaje: 'Producto agregado correctamente', endpoint: 'productos' },
      { id: 'formulario-pedido', mensaje: 'Pedido creado correctamente', endpoint: 'pedidos' },
      { id: 'formulario-cliente', mensaje: 'Cliente agregado correctamente', endpoint: 'clientes' },
      { id: 'formulario-proveedor', mensaje: 'Proveedor agregado correctamente', endpoint: 'proveedores' }
  ];
  
  formularios.forEach(form => {
      const formulario = document.getElementById(form.id);
      if (formulario) {
          formulario.addEventListener('submit', function(e) {
              e.preventDefault();
              
              // Verificar si es una actualización (tiene un campo de ID oculto)
              const idInput = this.querySelector('input[type="hidden"]');
              if (idInput && idInput.value) {
                  // Si hay un ID, la función de edición ya se encarga de esto
                  return;
              }
              
              const formData = new FormData(this);
              
              // Si el formulario incluye un archivo, usar FormData directamente
              if (formData.has('imagen') || formData.has('foto_perfil')) {
                  fetch(`${API_URL}/${form.endpoint}`, {
                      method: 'POST',
                      headers: {
                          'Authorization': `Bearer ${token}`
                      },
                      body: formData
                  })
                  .then(response => {
                      if (!response.ok) throw new Error('Error al procesar la solicitud');
                      return response.json();
                  })
                  .then(data => {
                      alert(form.mensaje);
                      this.reset();
                      cargarDatosAPI();
                  })
                  .catch(error => {
                      console.error('Error:', error);
                      alert('Error al procesar la solicitud: ' + error.message);
                  });
              } else {
                  // Si no hay archivos, convertir FormData a JSON
                  const formDataObj = {};
                  formData.forEach((value, key) => {
                      formDataObj[key] = value;
                  });
                  
                  fetch(`${API_URL}/${form.endpoint}`, {
                      method: 'POST',
                      headers: getAuthHeader(),
                      body: JSON.stringify(formDataObj)
                  })
                  .then(response => {
                      if (!response.ok) throw new Error('Error al procesar la solicitud');
                      return response.json();
                  })
                  .then(data => {
                      alert(form.mensaje);
                      this.reset();
                      cargarDatosAPI();
                  })
                  .catch(error => {
                      console.error('Error:', error);
                      alert('Error al procesar la solicitud: ' + error.message);
                  });
              }
          });
      }
  });
});