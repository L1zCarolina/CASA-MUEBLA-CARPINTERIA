document.addEventListener("DOMContentLoaded", () => {
  // Obtener referencias a elementos del DOM
  const formEditarPerfil = document.getElementById("form-editar-perfil")
  const nuevaFotoInput = document.getElementById("nueva-foto")
  const fotoPerfil = document.getElementById("foto-perfil")
  const nombreUsuario = document.getElementById("nombre-usuario")
  const emailUsuario = document.getElementById("email-usuario")
  const rolUsuario = document.getElementById("rol-usuario")
  const camposCliente = document.getElementById("campos-cliente")
  const mensajeEstado = document.getElementById("mensaje-estado")

  // Declarar la variable API_URL (asegúrate de que tenga el valor correcto)
  const API_URL = "http://localhost:3000/api" // Reemplaza con la URL correcta de tu API

  // Cargar datos del usuario
  cargarDatosUsuario()

  // Configurar vista previa de imagen
  nuevaFotoInput.addEventListener("change", function () {
    const file = this.files[0]

    if (file) {
      // Validar tipo de archivo
      const tiposPermitidos = ["image/jpeg", "image/jpg", "image/png"]
      if (!tiposPermitidos.includes(file.type)) {
        mostrarMensaje(
          "El archivo seleccionado no es una imagen válida. Por favor, selecciona una imagen en formato JPG, JPEG o PNG.",
          "error",
        )
        this.value = "" // Limpiar el input
        return
      }

      // Validar tamaño (2MB máximo)
      if (file.size > 2 * 1024 * 1024) {
        mostrarMensaje("La imagen es demasiado grande. El tamaño máximo permitido es 2MB.", "error")
        this.value = "" // Limpiar el input
        return
      }

      // Mostrar vista previa
      const reader = new FileReader()
      reader.onload = (e) => {
        fotoPerfil.src = e.target.result
      }
      reader.readAsDataURL(file)
    }
  })

  // Manejar envío del formulario
  formEditarPerfil.addEventListener("submit", async (e) => {
    e.preventDefault()

    // Mostrar mensaje de carga
    mostrarMensaje("Actualizando perfil...", "info")

    try {
      // Obtener el token del localStorage
      const token = localStorage.getItem("token")
      const usuario = JSON.parse(localStorage.getItem("usuario"))

      if (!token || !usuario) {
        mostrarMensaje("No has iniciado sesión. Por favor, inicia sesión para editar tu perfil.", "error")
        setTimeout(() => {
          window.location.href = "mi-cuenta.html"
        }, 2000)
        return
      }

      // Crear FormData con los datos del formulario
      const formData = new FormData(formEditarPerfil)

      // Agregar la foto si se seleccionó una nueva
      if (nuevaFotoInput.files[0]) {
        formData.append("foto_perfil", nuevaFotoInput.files[0])
      }

      // Enviar solicitud al servidor
      const response = await fetch(`${API_URL}/usuarios/${usuario.id_usuario}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || data.message || "Error al actualizar el perfil")
      }

      // Actualizar datos del usuario en localStorage
      const usuarioActualizado = {
        ...usuario,
        nombre_usuario: formData.get("nombre_usuario"),
        email_usuario: formData.get("email_usuario"),
        foto_perfil: data.foto_perfil || usuario.foto_perfil,
      }

      localStorage.setItem("usuario", JSON.stringify(usuarioActualizado))

      // Mostrar mensaje de éxito
      mostrarMensaje("Perfil actualizado correctamente", "success")

      // Actualizar la información mostrada
      nombreUsuario.textContent = usuarioActualizado.nombre_usuario
      emailUsuario.textContent = usuarioActualizado.email_usuario
    } catch (error) {
      console.error("Error:", error)
      mostrarMensaje(error.message || "Error al actualizar el perfil", "error")
    }
  })

  // Función para cargar datos del usuario
  async function cargarDatosUsuario() {
    try {
      const token = localStorage.getItem("token")
      const usuarioGuardado = JSON.parse(localStorage.getItem("usuario"))

      if (!token || !usuarioGuardado) {
        mostrarMensaje("No has iniciado sesión. Por favor, inicia sesión para editar tu perfil.", "error")
        setTimeout(() => {
          window.location.href = "mi-cuenta.html"
        }, 2000)
        return
      }

      // Mostrar datos del usuario guardado en localStorage
      nombreUsuario.textContent = usuarioGuardado.nombre_usuario
      emailUsuario.textContent = usuarioGuardado.email_usuario
      rolUsuario.textContent = `Rol: ${usuarioGuardado.rol.charAt(0).toUpperCase() + usuarioGuardado.rol.slice(1)}`

      // Cargar foto de perfil si existe
      if (usuarioGuardado.foto_perfil) {
        fotoPerfil.src = `${API_URL.replace("/api", "")}/uploads/${usuarioGuardado.foto_perfil}`
      }

      // Llenar el formulario con los datos actuales
      document.getElementById("nombre_usuario").value = usuarioGuardado.nombre_usuario
      document.getElementById("email_usuario").value = usuarioGuardado.email_usuario

      // Si es cliente, mostrar campos adicionales y cargar datos
      if (usuarioGuardado.rol === "cliente") {
        camposCliente.style.display = "block"

        // Obtener datos adicionales del cliente
        const response = await fetch(`${API_URL}/clientes`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })

        if (response.ok) {
          const clientes = await response.json()
          const clienteActual = clientes.find((cliente) => cliente.usuario_id === usuarioGuardado.id_usuario)

          if (clienteActual) {
            document.getElementById("telefono").value = clienteActual.telefono || ""
            document.getElementById("direccion").value = clienteActual.direccion || ""
          }
        }
      }
    } catch (error) {
      console.error("Error al cargar datos del usuario:", error)
      mostrarMensaje("Error al cargar datos del usuario", "error")
    }
  }

  // Función para mostrar mensajes
  function mostrarMensaje(texto, tipo) {
    mensajeEstado.textContent = texto
    mensajeEstado.className = "mensaje-estado"

    switch (tipo) {
      case "success":
        mensajeEstado.classList.add("mensaje-exito")
        break
      case "error":
        mensajeEstado.classList.add("mensaje-error")
        break
      case "info":
        mensajeEstado.classList.add("mensaje-info")
        break
    }

    // Hacer scroll al mensaje
    mensajeEstado.scrollIntoView({ behavior: "smooth" })
  }
})
