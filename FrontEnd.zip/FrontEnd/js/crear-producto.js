document.addEventListener("DOMContentLoaded", () => {
  // Obtener referencias a elementos del DOM
  const formularioProducto = document.getElementById("formulario-producto")
  const imagenInput = document.getElementById("imagen")
  const imagenPreview = document.getElementById("imagen-preview")
  const mensajeEstado = document.getElementById("mensaje-estado")

  // Declarar API_URL
  const API_URL = "/api" // Reemplaza con la URL correcta de tu API

  // Configurar vista previa de imagen
  imagenInput.addEventListener("change", function () {
    const file = this.files[0]

    if (file) {
      // Validar tipo de archivo
      const tiposPermitidos = ["image/jpeg", "image/jpg", "image/png"]
      if (!tiposPermitidos.includes(file.type)) {
        mostrarMensaje(
          "El archivo seleccionado no es una imagen válida. Por favor, selecciona una imagen en formato JPG, JPEG o PNG.",
          "error",
        )
        this.value = "" // Limpiar el input
        imagenPreview.innerHTML = ""
        return
      }

      // Validar tamaño (5MB máximo)
      if (file.size > 5 * 1024 * 1024) {
        mostrarMensaje("La imagen es demasiado grande. El tamaño máximo permitido es 5MB.", "error")
        this.value = "" // Limpiar el input
        imagenPreview.innerHTML = ""
        return
      }

      // Mostrar vista previa
      const reader = new FileReader()
      reader.onload = (e) => {
        imagenPreview.innerHTML = `
                    <img src="${e.target.result}" alt="Vista previa">
                `
      }
      reader.readAsDataURL(file)
    } else {
      imagenPreview.innerHTML = ""
    }
  })

  // Manejar envío del formulario
  formularioProducto.addEventListener("submit", async (e) => {
    e.preventDefault()

    // Mostrar mensaje de carga
    mostrarMensaje("Creando producto...", "info")

    try {
      // Crear FormData con los datos del formulario
      const formData = new FormData(formularioProducto)

      // Enviar solicitud al servidor
      const response = await fetch(`${API_URL}/productos`, {
        method: "POST",
        body: formData,
        // No incluir Content-Type para que el navegador lo establezca automáticamente con el boundary correcto
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || data.message || "Error al crear el producto")
      }

      // Mostrar mensaje de éxito
      mostrarMensaje("Producto creado exitosamente", "success")

      // Limpiar formulario
      formularioProducto.reset()
      imagenPreview.innerHTML = ""

      // Opcional: redirigir después de un tiempo
      // setTimeout(() => {
      //     window.location.href = 'productos.html';
      // }, 2000);
    } catch (error) {
      console.error("Error:", error)
      mostrarMensaje(error.message || "Error al crear el producto", "error")
    }
  })

  // Función para mostrar mensajes
  function mostrarMensaje(texto, tipo) {
    mensajeEstado.textContent = texto
    mensajeEstado.className = "mensaje-estado"

    switch (tipo) {
      case "success":
        mensajeEstado.classList.add("mensaje-exito")
        break
      case "error":
        mensajeEstado.classList.add("mensaje-error")
        break
      case "info":
        mensajeEstado.classList.add("mensaje-info")
        break
    }

    // Hacer scroll al mensaje
    mensajeEstado.scrollIntoView({ behavior: "smooth" })
  }
})
