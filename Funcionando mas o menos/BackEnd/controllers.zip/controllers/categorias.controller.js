/// CONTROLADORES DEL MODULO ///

const db = require("../db/db")

//---------------- METODOS HTTP ---------------------///

/// METODO GET  ///

// Para todas las categorías
const allCategories = (req, res) => {
  const sql = "SELECT * FROM categorias ORDER BY id_categoria DESC"
  db.query(sql, (error, rows) => {
    if (error) {
      console.error("Error en allCategories:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }

    // ← ASEGURAR QUE SIEMPRE SE ENVÍE ARRAY
    const categorias = Array.isArray(rows) ? rows : []
    console.log(`Enviando ${categorias.length} categorías`)
    res.json(categorias)
  })
}

// Para una categoría específica
const showCategory = (req, res) => {
  const { id } = req.params
  const sql = "SELECT * FROM categorias WHERE id_categoria = ?"
  db.query(sql, [id], (error, rows) => {
    if (error) {
      console.error("Error en showCategory:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    if (rows.length === 0) {
      return res.status(404).json({ error: "ERROR: No existe la categoría buscada" })
    }
    res.json(rows[0])
  })
}

/// METODO POST  ///

// Crear nueva categoría
const storeCategory = (req, res) => {
  console.log("=== CREAR CATEGORÍA ===")
  console.log("Datos del formulario:", req.body)

  const { nombre_categoria, descripcion_categoria } = req.body

  // Validación básica
  if (!nombre_categoria) {
    return res.status(400).json({
      error: "El nombre de la categoría es obligatorio",
    })
  }

  // Verificar si la categoría ya existe
  const checkSql = "SELECT id_categoria FROM categorias WHERE nombre_categoria = ?"
  db.query(checkSql, [nombre_categoria], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar categoría:", checkError)
      return res.status(500).json({ error: "Error al verificar categoría" })
    }

    if (checkResults.length > 0) {
      return res.status(409).json({ error: "La categoría ya existe" })
    }

    const sql = "INSERT INTO categorias (nombre_categoria, descripcion_categoria) VALUES (?,?)"
    db.query(sql, [nombre_categoria, descripcion_categoria || null], (error, result) => {
      if (error) {
        console.error("Error al crear categoría:", error)
        return res.status(500).json({
          error: "ERROR: No se pudo agregar la categoría",
        })
      }

      // ← RESPUESTA CONSISTENTE
      const categoria = {
        id_categoria: result.insertId,
        nombre_categoria,
        descripcion_categoria: descripcion_categoria || null,
        activa: true,
      }

      console.log("Categoría creada exitosamente:", categoria)
      res.status(201).json({
        mensaje: "✅ Categoría creada exitosamente",
        categoria: categoria,
      })
    })
  })
}

/// METODO PUT  ///

// Actualizar categoría
const updateCategory = (req, res) => {
  console.log("=== ACTUALIZAR CATEGORÍA ===")
  const { id } = req.params
  console.log("ID a actualizar:", id)
  console.log("Datos del formulario:", req.body)

  const { nombre_categoria, descripcion_categoria } = req.body

  // Validación básica
  if (!nombre_categoria) {
    return res.status(400).json({
      error: "El nombre de la categoría es obligatorio",
    })
  }

  // ← VERIFICAR QUE LA CATEGORÍA EXISTE ANTES DE ACTUALIZAR
  const checkSql = "SELECT * FROM categorias WHERE id_categoria = ?"
  db.query(checkSql, [id], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar categoría:", checkError)
      return res.status(500).json({ error: "Error al verificar categoría" })
    }

    if (checkResults.length === 0) {
      return res.status(404).json({ error: "Categoría no encontrada" })
    }

    // Verificar si el nombre ya existe en otra categoría
    const nameCheckSql = "SELECT id_categoria FROM categorias WHERE nombre_categoria = ? AND id_categoria != ?"
    db.query(nameCheckSql, [nombre_categoria, id], (nameError, nameResults) => {
      if (nameError) {
        console.error("Error al verificar nombre:", nameError)
        return res.status(500).json({ error: "Error al verificar nombre" })
      }

      if (nameResults.length > 0) {
        return res.status(409).json({ error: "Ya existe una categoría con ese nombre" })
      }

      const updateSql = "UPDATE categorias SET nombre_categoria = ?, descripcion_categoria = ? WHERE id_categoria = ?"
      db.query(updateSql, [nombre_categoria, descripcion_categoria || null, id], (error, result) => {
        if (error) {
          console.error("Error al actualizar categoría:", error)
          return res.status(500).json({ error: "ERROR: No se pudo actualizar la categoría" })
        }

        if (result.affectedRows === 0) {
          return res.status(404).json({ error: "ERROR: La categoría a modificar no existe" })
        }

        // ← RESPUESTA CONSISTENTE
        const categoriaActualizada = {
          id_categoria: Number.parseInt(id),
          nombre_categoria,
          descripcion_categoria: descripcion_categoria || null,
          activa: true,
        }

        console.log("Categoría actualizada exitosamente:", categoriaActualizada)
        res.json({
          mensaje: "✅ Categoría actualizada exitosamente",
          categoria: categoriaActualizada,
        })
      })
    })
  })
}

/// METODO DELETE ///

// Eliminar categoría
const destroyCategory = (req, res) => {
  const { id } = req.params

  // Verificar si hay productos usando esta categoría
  const checkProductsSql = "SELECT COUNT(*) as count FROM productos WHERE id_categoria = ?"
  db.query(checkProductsSql, [id], (checkError, checkResults) => {
    if (checkError) {
      console.error("Error al verificar productos:", checkError)
      return res.status(500).json({ error: "Error al verificar productos" })
    }

    const productCount = checkResults[0].count
    if (productCount > 0) {
      return res.status(409).json({
        error: `No se puede eliminar la categoría porque tiene ${productCount} producto(s) asociado(s)`,
      })
    }

    const sql = "DELETE FROM categorias WHERE id_categoria = ?"
    db.query(sql, [id], (error, result) => {
      if (error) {
        console.error("Error al eliminar categoría:", error)
        return res.status(500).json({ error: "ERROR: No se pudo eliminar la categoría" })
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: "ERROR: La categoría a borrar no existe" })
      }
      res.json({ mensaje: "✅ Categoría eliminada exitosamente" })
    })
  })
}

// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
  allCategories,
  showCategory,
  storeCategory,
  updateCategory,
  destroyCategory,
}
