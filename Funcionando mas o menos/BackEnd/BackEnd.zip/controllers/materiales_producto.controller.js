/// CONTROLADORES DEL MODULO ///

const db = require("../db/db")

//// METODO GET  /////

// Para todos los materiales
const allMaterials = (req, res) => {
  const sql = "SELECT * FROM materiales ORDER BY id_material DESC"
  db.query(sql, (error, rows) => {
    if (error) {
      console.error("Error en allMaterials:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    const materiales = Array.isArray(rows) ? rows : []
    res.json(materiales)
  })
}

// Para un material
const showMaterial = (req, res) => {
  const { id } = req.params
  const sql = "SELECT * FROM materiales WHERE id_material = ?"
  db.query(sql, [id], (error, rows) => {
    if (error) {
      console.error("Error en showMaterial:", error)
      return res.status(500).json({ error: "ERROR: Intente mas tarde por favor" })
    }
    if (rows.length == 0) {
      return res.status(404).json({ error: "ERROR: No existe el material buscado" })
    }
    res.json(rows[0])
  })
}

//// METODO POST  ////
const storeMaterial = (req, res) => {
  const { nombre_material, descripcion_material, unidad_medida, precio_unitario, stock, stock_minimo, proveedor } =
    req.body

  // Validaciones básicas
  if (!nombre_material || !unidad_medida || !precio_unitario || stock === undefined) {
    return res
      .status(400)
      .json({ error: "Campos obligatorios: nombre_material, unidad_medida, precio_unitario, stock" })
  }

  const sql =
    "INSERT INTO materiales (nombre_material, descripcion_material, unidad_medida, precio_unitario, stock, stock_minimo, proveedor) VALUES (?,?,?,?,?,?,?)"

  db.query(
    sql,
    [
      nombre_material,
      descripcion_material || null,
      unidad_medida,
      precio_unitario,
      stock,
      stock_minimo || 5,
      proveedor || null,
    ],
    (error, result) => {
      if (error) {
        console.error("Error al crear material:", error)
        return res.status(500).json({ error: "ERROR: No se pudo crear el material" })
      }
      const material = {
        id_material: result.insertId,
        nombre_material,
        descripcion_material: descripcion_material || null,
        unidad_medida,
        precio_unitario: Number.parseFloat(precio_unitario),
        stock: Number.parseInt(stock),
        stock_minimo: stock_minimo || 5,
        proveedor: proveedor || null,
      }
      res.status(201).json({
        mensaje: "Material creado exitosamente",
        material: material,
      })
    },
  )
}

//// METODO PUT  ////
const updateMaterial = (req, res) => {
  const { id } = req.params
  const { nombre_material, descripcion_material, unidad_medida, precio_unitario, stock, stock_minimo, proveedor } =
    req.body

  // Validaciones básicas
  if (!nombre_material || !unidad_medida || !precio_unitario || stock === undefined) {
    return res
      .status(400)
      .json({ error: "Campos obligatorios: nombre_material, unidad_medida, precio_unitario, stock" })
  }

  const sql =
    "UPDATE materiales SET nombre_material = ?, descripcion_material = ?, unidad_medida = ?, precio_unitario = ?, stock = ?, stock_minimo = ?, proveedor = ? WHERE id_material = ?"
  db.query(
    sql,
    [
      nombre_material,
      descripcion_material || null,
      unidad_medida,
      precio_unitario,
      stock,
      stock_minimo || 5,
      proveedor || null,
      id,
    ],
    (error, result) => {
      if (error) {
        console.error("Error al actualizar material:", error)
        return res.status(500).json({ error: "ERROR: No se pudo actualizar el material" })
      }
      if (result.affectedRows == 0) {
        return res.status(404).json({ error: "ERROR: El material a modificar no existe" })
      }

      const materialActualizado = {
        id_material: Number.parseInt(id),
        nombre_material,
        descripcion_material: descripcion_material || null,
        unidad_medida,
        precio_unitario: Number.parseFloat(precio_unitario),
        stock: Number.parseInt(stock),
        stock_minimo: stock_minimo || 5,
        proveedor: proveedor || null,
      }
      res.json({
        mensaje: "Material actualizado exitosamente",
        material: materialActualizado,
      })
    },
  )
}

//// METODO DELETE ////
const destroyMaterial = (req, res) => {
  const { id } = req.params
  const sql = "DELETE FROM materiales WHERE id_material = ?"
  db.query(sql, [id], (error, result) => {
    if (error) {
      console.error("Error al eliminar material:", error)
      return res.status(500).json({ error: "ERROR: No se pudo eliminar el material" })
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "ERROR: El material a borrar no existe" })
    }
    res.json({ mensaje: "Material eliminado exitosamente" })
  })
}

// EXPORTAR DEL MODULO TODAS LAS FUNCIONES
module.exports = {
  allMaterials,
  showMaterial,
  storeMaterial,
  updateMaterial,
  destroyMaterial,
}
